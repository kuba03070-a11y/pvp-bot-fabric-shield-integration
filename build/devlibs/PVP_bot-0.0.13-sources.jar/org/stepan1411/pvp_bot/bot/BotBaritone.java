package org.stepan1411.pvp_bot.bot;

import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.stepan1411.pvp_bot.bot.pathfinding.AStarPathfinder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Server-side pathfinding system for bots
 * 
 * NOTE: Original Baritone is designed for client-side use and requires ClientPlayerEntity.
 * This implementation uses A* pathfinding algorithm adapted for ServerPlayerEntity.
 */
public class BotBaritone {
    
    private static final Map<String, PathState> pathStates = new HashMap<>();
    
    private static class PathState {
        List<Vec3d> currentPath;
        int currentIndex;
        Vec3d targetPos;
        long lastPathTime;
        
        PathState(List<Vec3d> path, Vec3d target) {
            this.currentPath = path;
            this.currentIndex = 0;
            this.targetPos = target;
            this.lastPathTime = System.currentTimeMillis();
        }
    }
    
    /**
     * Check if pathfinding is available
     * Always returns true as we use server-side A* pathfinding
     */
    public static boolean isBaritoneAvailable(ServerPlayerEntity bot) {
        return true;
    }
    
    /**
     * Move bot to a specific position using A* pathfinding
     */
    public static boolean goToPosition(ServerPlayerEntity bot, Vec3d targetPos) {
        String botName = bot.getName().getString();
        PathState state = pathStates.get(botName);
        
        // Check if we need to recalculate path
        boolean needNewPath = state == null || 
                              state.currentPath == null || 
                              state.currentIndex >= state.currentPath.size() ||
                              !state.targetPos.isInRange(targetPos, 2.0) ||
                              System.currentTimeMillis() - state.lastPathTime > 5000; // Recalc every 5 sec
        
        if (needNewPath) {
            List<Vec3d> path = AStarPathfinder.findPath(bot, targetPos);
            if (path == null || path.isEmpty()) {
                return false; // No path found
            }
            state = new PathState(path, targetPos);
            pathStates.put(botName, state);
        }
        
        // Follow current path
        if (state.currentIndex < state.currentPath.size()) {
            Vec3d nextPoint = state.currentPath.get(state.currentIndex);
            Vec3d botPos = new Vec3d(bot.getX(), bot.getY(), bot.getZ());
            
            // Debug visualization - show full path
            if (BotDebug.isEnabled(botName)) {
                BotDebug.showPath(bot, targetPos, new java.util.LinkedList<>(), state.currentPath);
            }
            
            // Check if reached current waypoint (smaller radius for precision)
            double horizontalDist = Math.sqrt(
                Math.pow(nextPoint.x - botPos.x, 2) + 
                Math.pow(nextPoint.z - botPos.z, 2)
            );
            double verticalDist = Math.abs(nextPoint.y - botPos.y);
            
            // More precise waypoint checking
            if (horizontalDist < 0.5 && verticalDist < 1.0) {
                state.currentIndex++;
                if (state.currentIndex >= state.currentPath.size()) {
                    // Reached end of path
                    return true;
                }
                nextPoint = state.currentPath.get(state.currentIndex);
            }
            
            // Move toward next waypoint using Carpet commands with our pathfinding
            BotNavigation.NavigationState navState = BotNavigation.getState(bot.getName().getString());
            if (navState.jumpCooldown > 0) navState.jumpCooldown--;
            if (navState.avoidTicks > 0) navState.avoidTicks--;
            
            // Calculate direction to waypoint
            double dx = nextPoint.x - botPos.x;
            double dz = nextPoint.z - botPos.z;
            double dist = Math.sqrt(dx * dx + dz * dz);
            
            if (dist > 0.1) {
                // Calculate yaw to look at waypoint
                double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
                double dy = nextPoint.y - botPos.y;
                
                // Try Carpet commands first
                if (CarpetMovement.isCarpetAvailable()) {
                    MinecraftServer server = bot.getCommandSource().getServer();
                    
                    // Look at waypoint
                    CarpetMovement.executeCommand(server, String.format("player %s look %.1f 0", botName, yaw));
                    
                    // Move forward toward waypoint
                    CarpetMovement.executeCommand(server, String.format("player %s move forward", botName));
                    
                    // Sprint if far
                    if (dist > 3.0) {
                        CarpetMovement.executeCommand(server, String.format("player %s sprint", botName));
                    }
                    
                    // Jump if needed
                    if (dy > 0.5 && bot.isOnGround() && navState.jumpCooldown <= 0) {
                        CarpetMovement.executeCommand(server, String.format("player %s jump", botName));
                        navState.jumpCooldown = 10;
                    }
                } else {
                    // Fallback to manual movement
                    dx /= dist;
                    dz /= dist;
                    
                    // Look at waypoint
                    float yawF = (float) yaw;
                    bot.setYaw(yawF);
                    bot.setHeadYaw(yawF);
                    
                    // Always sprint for speed
                    bot.setSprinting(true);
                    bot.forwardSpeed = 1.0f;
                    
                    // Apply velocity - stronger for faster movement
                    bot.addVelocity(dx * 0.15, 0, dz * 0.15);
                    
                    // Bhop - jump while running for extra speed
                    BotSettings settings = BotSettings.get();
                    if (bot.isOnGround() && navState.jumpCooldown <= 0) {
                        // Jump if going up OR bhop if enabled and moving fast
                        if (dy > 0.5) {
                            // Need to jump up
                            bot.jump();
                            navState.jumpCooldown = 10;
                        } else if (settings.isBhopEnabled() && dist > 2.0) {
                            // Bhop for speed on flat ground
                            bot.jump();
                            navState.jumpCooldown = settings.getBhopCooldown();
                        }
                    }
                }
            }
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Move bot near an entity using A* pathfinding
     */
    public static boolean goToEntity(ServerPlayerEntity bot, Entity target, double distance) {
        Vec3d targetPos = new Vec3d(target.getX(), target.getY(), target.getZ());
        return goToPosition(bot, targetPos);
    }
    
    /**
     * Move bot away from an entity
     * Uses direct navigation instead of pathfinding for retreat
     */
    public static boolean moveAwayFrom(ServerPlayerEntity bot, Entity target, double minDistance) {
        // For retreat, direct navigation is faster than pathfinding
        return false; // Let BotNavigation handle it
    }
    
    /**
     * Stop current pathfinding
     */
    public static void stop(ServerPlayerEntity bot) {
        String botName = bot.getName().getString();
        pathStates.remove(botName);
    }
    
    /**
     * Check if bot is currently pathfinding
     */
    public static boolean isPathing(ServerPlayerEntity bot) {
        String botName = bot.getName().getString();
        PathState state = pathStates.get(botName);
        return state != null && state.currentPath != null && state.currentIndex < state.currentPath.size();
    }
    
    /**
     * Get distance to current goal
     */
    public static double getDistanceToGoal(ServerPlayerEntity bot) {
        String botName = bot.getName().getString();
        PathState state = pathStates.get(botName);
        if (state == null || state.targetPos == null) {
            return -1;
        }
        Vec3d botPos = new Vec3d(bot.getX(), bot.getY(), bot.getZ());
        return botPos.distanceTo(state.targetPos);
    }
    
    /**
     * Remove pathfinding state when bot is removed
     */
    public static void removeBaritone(String botName) {
        pathStates.remove(botName);
    }
}
