package org.stepan1411.pvp_bot.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import org.stepan1411.pvp_bot.bot.BotCombat;
import org.stepan1411.pvp_bot.bot.BotDebug;
import org.stepan1411.pvp_bot.bot.BotFaction;
import org.stepan1411.pvp_bot.bot.BotKits;
import org.stepan1411.pvp_bot.bot.BotManager;
import org.stepan1411.pvp_bot.bot.BotNameGenerator;
import org.stepan1411.pvp_bot.bot.BotPath;
import org.stepan1411.pvp_bot.bot.BotSettings;
import org.stepan1411.pvp_bot.gui.SettingsGui;
import org.stepan1411.pvp_bot.stats.StatsReporter;

import java.lang.reflect.Method;
import java.util.stream.Collectors;

public class BotCommand {
    
    // РџСЂРѕРІРµСЂРєР° РЅР°Р»РёС‡РёСЏ InvView
    private static final boolean HAS_INVVIEW = FabricLoader.getInstance().isModLoaded("invview");
    
    // РџРѕРґСЃРєР°Р·РєРё РґР»СЏ РёРјС‘РЅ Р±РѕС‚РѕРІ
    private static final SuggestionProvider<class_2168> BOT_SUGGESTIONS = (ctx, builder) -> {
        var server = ctx.getSource().method_9211();
        var aliveBots = BotManager.getAllBots().stream()
            .filter(name -> {
                var bot = server.method_3760().method_14566(name);
                return bot != null && bot.method_5805();
            })
            .collect(Collectors.toList());
        return class_2172.method_9265(aliveBots, builder);
    };
    
    // РџРѕРґСЃРєР°Р·РєРё РґР»СЏ С†РµР»РµР№ (РІСЃРµ РёРіСЂРѕРєРё РЅР° СЃРµСЂРІРµСЂРµ)
    private static final SuggestionProvider<class_2168> TARGET_SUGGESTIONS = (ctx, builder) -> 
        class_2172.method_9265(
            ctx.getSource().method_9211().method_3760().method_14571().stream()
                .map(p -> p.method_5477().getString())
                .collect(Collectors.toList()), 
            builder);
    
    // РџРѕРґСЃРєР°Р·РєРё РґР»СЏ РІСЃРµС… РёРіСЂРѕРєРѕРІ (Р±РѕС‚С‹ + РёРіСЂРѕРєРё)
    private static final SuggestionProvider<class_2168> PLAYER_SUGGESTIONS = TARGET_SUGGESTIONS;
    
    // РџРѕРґСЃРєР°Р·РєРё РґР»СЏ С„СЂР°РєС†РёР№
    private static final SuggestionProvider<class_2168> FACTION_SUGGESTIONS = (ctx, builder) -> 
        class_2172.method_9265(BotFaction.getAllFactions(), builder);
    
    // РџРѕРґСЃРєР°Р·РєРё РґР»СЏ РєРёС‚РѕРІ
    private static final SuggestionProvider<class_2168> KIT_SUGGESTIONS = (ctx, builder) -> 
        class_2172.method_9265(BotKits.getKitNames(), builder);
    
    // РџРѕРґСЃРєР°Р·РєРё РґР»СЏ РїСѓС‚РµР№
    private static final SuggestionProvider<class_2168> PATH_SUGGESTIONS = (ctx, builder) -> 
        class_2172.method_9265(BotPath.getAllPaths().keySet(), builder);

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("pvpbot")
                
                // /pvpbot spawn [name] - Р±РµР· РёРјРµРЅРё РіРµРЅРµСЂРёСЂСѓРµС‚ СЃР»СѓС‡Р°Р№РЅРѕРµ
                .then(class_2170.method_9247("spawn")
                    .executes(ctx -> spawnBot(ctx.getSource(), BotNameGenerator.generateUniqueName()))
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .executes(ctx -> spawnBot(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                    )
                )
                
                // /pvpbot massspawn <num> - СЃРїР°РІРЅРёС‚ РЅРµСЃРєРѕР»СЊРєРѕ Р±РѕС‚РѕРІ СЃ СЂР°РЅРґРѕРјРЅС‹РјРё РёРјРµРЅР°РјРё
                .then(class_2170.method_9247("massspawn")
                    .then(class_2170.method_9244("count", IntegerArgumentType.integer(1, 50))
                        .executes(ctx -> massSpawnBots(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "count")))
                    )
                )
                
                // /pvpbot remove <name> - СЃ РїРѕРґСЃРєР°Р·РєР°РјРё Р±РѕС‚РѕРІ
                .then(class_2170.method_9247("remove")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(BOT_SUGGESTIONS)
                        .executes(ctx -> removeBot(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                    )
                )
                
                // /pvpbot removeall
                .then(class_2170.method_9247("removeall")
                    .executes(ctx -> removeAllBots(ctx.getSource()))
                )
                
                // /pvpbot list
                .then(class_2170.method_9247("list")
                    .executes(ctx -> listBots(ctx.getSource()))
                )
                
                // /pvpbot sync [name] - СЃРёРЅС…СЂРѕРЅРёР·РёСЂРѕРІР°С‚СЊ СЃРїРёСЃРѕРє Р±РѕС‚РѕРІ СЃ СЃРµСЂРІРµСЂРѕРј
                .then(class_2170.method_9247("sync")
                    .executes(ctx -> syncBots(ctx.getSource()))
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(PLAYER_SUGGESTIONS)
                        .executes(ctx -> syncBot(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                    )
                )
                
                // /pvpbot debug - СЃРёСЃС‚РµРјР° РѕС‚Р»Р°РґРєРё
                .then(class_2170.method_9247("debug")
                    .then(class_2170.method_9244("bot", StringArgumentType.word())
                        .suggests(BOT_SUGGESTIONS)
                        
                        // /pvpbot debug <bot> path [true/false]
                        .then(class_2170.method_9247("path")
                            .executes(ctx -> toggleDebugPath(ctx.getSource(), StringArgumentType.getString(ctx, "bot")))
                            .then(class_2170.method_9244("enabled", BoolArgumentType.bool())
                                .executes(ctx -> setDebugPath(ctx.getSource(), StringArgumentType.getString(ctx, "bot"), BoolArgumentType.getBool(ctx, "enabled")))
                            )
                        )
                        
                        // /pvpbot debug <bot> target [true/false]
                        .then(class_2170.method_9247("target")
                            .executes(ctx -> toggleDebugTarget(ctx.getSource(), StringArgumentType.getString(ctx, "bot")))
                            .then(class_2170.method_9244("enabled", BoolArgumentType.bool())
                                .executes(ctx -> setDebugTarget(ctx.getSource(), StringArgumentType.getString(ctx, "bot"), BoolArgumentType.getBool(ctx, "enabled")))
                            )
                        )
                        
                        // /pvpbot debug <bot> combat [true/false]
                        .then(class_2170.method_9247("combat")
                            .executes(ctx -> toggleDebugCombat(ctx.getSource(), StringArgumentType.getString(ctx, "bot")))
                            .then(class_2170.method_9244("enabled", BoolArgumentType.bool())
                                .executes(ctx -> setDebugCombat(ctx.getSource(), StringArgumentType.getString(ctx, "bot"), BoolArgumentType.getBool(ctx, "enabled")))
                            )
                        )
                        
                        // /pvpbot debug <bot> navigation [true/false]
                        .then(class_2170.method_9247("navigation")
                            .executes(ctx -> toggleDebugNavigation(ctx.getSource(), StringArgumentType.getString(ctx, "bot")))
                            .then(class_2170.method_9244("enabled", BoolArgumentType.bool())
                                .executes(ctx -> setDebugNavigation(ctx.getSource(), StringArgumentType.getString(ctx, "bot"), BoolArgumentType.getBool(ctx, "enabled")))
                            )
                        )
                        
                        // /pvpbot debug <bot> all [true/false]
                        .then(class_2170.method_9247("all")
                            .executes(ctx -> toggleDebugAll(ctx.getSource(), StringArgumentType.getString(ctx, "bot")))
                            .then(class_2170.method_9244("enabled", BoolArgumentType.bool())
                                .executes(ctx -> setDebugAll(ctx.getSource(), StringArgumentType.getString(ctx, "bot"), BoolArgumentType.getBool(ctx, "enabled")))
                            )
                        )
                        
                        // /pvpbot debug <bot> status
                        .then(class_2170.method_9247("status")
                            .executes(ctx -> showDebugStatus(ctx.getSource(), StringArgumentType.getString(ctx, "bot")))
                        )
                    )
                )
                
                // /pvpbot menu - РѕС‚РєСЂС‹С‚СЊ С‚РµСЃС‚РѕРІРѕРµ РјРµРЅСЋ
                .then(class_2170.method_9247("menu")
                    .executes(ctx -> openTestMenu(ctx.getSource()))
                )
                
                // /pvpbot settings
                .then(class_2170.method_9247("settings")
                    .executes(ctx -> showSettings(ctx.getSource()))
                    
                    // /pvpbot settings gui - РѕС‚РєСЂС‹С‚СЊ GUI РЅР°СЃС‚СЂРѕРµРє
                    .then(class_2170.method_9247("gui")
                        .executes(ctx -> openSettingsGui(ctx.getSource()))
                    )
                    
                    // /pvpbot settings autoarmor [true/false]
                    .then(class_2170.method_9247("autoarmor")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("autoarmor: " + BotSettings.get().isAutoEquipArmor()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setAutoEquipArmor(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Auto equip armor: " + BotSettings.get().isAutoEquipArmor()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings autoweapon [true/false]
                    .then(class_2170.method_9247("autoweapon")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("autoweapon: " + BotSettings.get().isAutoEquipWeapon()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setAutoEquipWeapon(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Auto equip weapon: " + BotSettings.get().isAutoEquipWeapon()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings droparmor [true/false]
                    .then(class_2170.method_9247("droparmor")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("droparmor: " + BotSettings.get().isDropWorseArmor()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setDropWorseArmor(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Drop worse armor: " + BotSettings.get().isDropWorseArmor()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings dropweapon [true/false]
                    .then(class_2170.method_9247("dropweapon")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("dropweapon: " + BotSettings.get().isDropWorseWeapons()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setDropWorseWeapons(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Drop worse weapons: " + BotSettings.get().isDropWorseWeapons()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings dropdistance [1-10]
                    .then(class_2170.method_9247("dropdistance")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("dropdistance: " + BotSettings.get().getDropDistance()), false); return 1; })
                        .then(class_2170.method_9244("value", DoubleArgumentType.doubleArg(1.0, 10.0))
                            .executes(ctx -> {
                                BotSettings.get().setDropDistance(DoubleArgumentType.getDouble(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Drop distance: " + BotSettings.get().getDropDistance()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings interval [1-100]
                    .then(class_2170.method_9247("interval")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("interval: " + BotSettings.get().getCheckInterval() + " ticks"), false); return 1; })
                        .then(class_2170.method_9244("ticks", IntegerArgumentType.integer(1, 100))
                            .executes(ctx -> {
                                BotSettings.get().setCheckInterval(IntegerArgumentType.getInteger(ctx, "ticks"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Check interval: " + BotSettings.get().getCheckInterval() + " ticks"), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings minarmorlevel [0-100]
                    .then(class_2170.method_9247("minarmorlevel")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("minarmorlevel: " + BotSettings.get().getMinArmorLevel()), false); return 1; })
                        .then(class_2170.method_9244("level", IntegerArgumentType.integer(0, 100))
                            .executes(ctx -> {
                                BotSettings.get().setMinArmorLevel(IntegerArgumentType.getInteger(ctx, "level"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Min armor level: " + BotSettings.get().getMinArmorLevel() + " (0=any, 20=leather+, 40=gold+, 50=chain+, 60=iron+, 80=diamond+, 100=netherite)"), true);
                                return 1;
                            })
                        )
                    )
                    
                    // === Combat Settings (СЃ РїРѕРєР°Р·РѕРј С‚РµРєСѓС‰РµРіРѕ Р·РЅР°С‡РµРЅРёСЏ Р±РµР· Р°СЂРіСѓРјРµРЅС‚Р°) ===
                    .then(class_2170.method_9247("combat")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("combat: " + BotSettings.get().isCombatEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setCombatEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Combat enabled: " + BotSettings.get().isCombatEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("revenge")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("revenge: " + BotSettings.get().isRevengeEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setRevengeEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Revenge mode: " + BotSettings.get().isRevengeEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("autotarget")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("autotarget: " + BotSettings.get().isAutoTargetEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setAutoTargetEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Auto target: " + BotSettings.get().isAutoTargetEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("targetplayers")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("targetplayers: " + BotSettings.get().isTargetPlayers()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setTargetPlayers(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Target players: " + BotSettings.get().isTargetPlayers()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("targetmobs")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("targetmobs: " + BotSettings.get().isTargetHostileMobs()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setTargetHostileMobs(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Target hostile mobs: " + BotSettings.get().isTargetHostileMobs()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("targetbots")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("targetbots: " + BotSettings.get().isTargetOtherBots()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setTargetOtherBots(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Target other bots: " + BotSettings.get().isTargetOtherBots()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("criticals")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("criticals: " + BotSettings.get().isCriticalsEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setCriticalsEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Criticals: " + BotSettings.get().isCriticalsEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("ranged")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("ranged: " + BotSettings.get().isRangedEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setRangedEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Ranged weapons: " + BotSettings.get().isRangedEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("mace")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("mace: " + BotSettings.get().isMaceEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setMaceEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Mace combat: " + BotSettings.get().isMaceEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("attackcooldown")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("attackcooldown: " + BotSettings.get().getAttackCooldown() + " ticks"), false); return 1; })
                        .then(class_2170.method_9244("ticks", IntegerArgumentType.integer(1, 40))
                            .executes(ctx -> {
                                BotSettings.get().setAttackCooldown(IntegerArgumentType.getInteger(ctx, "ticks"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Attack cooldown: " + BotSettings.get().getAttackCooldown() + " ticks"), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("meleerange")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("meleerange: " + BotSettings.get().getMeleeRange()), false); return 1; })
                        .then(class_2170.method_9244("range", DoubleArgumentType.doubleArg(2.0, 6.0))
                            .executes(ctx -> {
                                BotSettings.get().setMeleeRange(DoubleArgumentType.getDouble(ctx, "range"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Melee range: " + BotSettings.get().getMeleeRange()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("movespeed")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("movespeed: " + BotSettings.get().getMoveSpeed()), false); return 1; })
                        .then(class_2170.method_9244("speed", DoubleArgumentType.doubleArg(0.1, 2.0))
                            .executes(ctx -> {
                                BotSettings.get().setMoveSpeed(DoubleArgumentType.getDouble(ctx, "speed"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Move speed: " + BotSettings.get().getMoveSpeed()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // === Navigation Settings ===
                    .then(class_2170.method_9247("bhop")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("bhop: " + BotSettings.get().isBhopEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setBhopEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Bhop enabled: " + BotSettings.get().isBhopEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("bhopcooldown")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("bhopcooldown: " + BotSettings.get().getBhopCooldown() + " ticks"), false); return 1; })
                        .then(class_2170.method_9244("ticks", IntegerArgumentType.integer(5, 30))
                            .executes(ctx -> {
                                BotSettings.get().setBhopCooldown(IntegerArgumentType.getInteger(ctx, "ticks"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Bhop cooldown: " + BotSettings.get().getBhopCooldown() + " ticks"), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("jumpboost")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("jumpboost: " + BotSettings.get().getJumpBoost()), false); return 1; })
                        .then(class_2170.method_9244("boost", DoubleArgumentType.doubleArg(0.0, 0.5))
                            .executes(ctx -> {
                                BotSettings.get().setJumpBoost(DoubleArgumentType.getDouble(ctx, "boost"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Jump boost: " + BotSettings.get().getJumpBoost()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("idle")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("idle: " + BotSettings.get().isIdleWanderEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setIdleWanderEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Idle wander: " + BotSettings.get().isIdleWanderEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("usebaritone")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("usebaritone: " + BotSettings.get().isUseBaritone()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setUseBaritone(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Use Baritone: " + BotSettings.get().isUseBaritone()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("idleradius")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("idleradius: " + BotSettings.get().getIdleWanderRadius()), false); return 1; })
                        .then(class_2170.method_9244("radius", DoubleArgumentType.doubleArg(3.0, 50.0))
                            .executes(ctx -> {
                                BotSettings.get().setIdleWanderRadius(DoubleArgumentType.getDouble(ctx, "radius"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Idle wander radius: " + BotSettings.get().getIdleWanderRadius()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // === Realism Settings ===
                    .then(class_2170.method_9247("friendlyfire")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("friendlyfire: " + BotSettings.get().isFriendlyFireEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setFriendlyFireEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Friendly fire: " + BotSettings.get().isFriendlyFireEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("misschance")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("misschance: " + BotSettings.get().getMissChance() + "%"), false); return 1; })
                        .then(class_2170.method_9244("percent", IntegerArgumentType.integer(0, 100))
                            .executes(ctx -> {
                                BotSettings.get().setMissChance(IntegerArgumentType.getInteger(ctx, "percent"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Miss chance: " + BotSettings.get().getMissChance() + "%"), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("mistakechance")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("mistakechance: " + BotSettings.get().getMistakeChance() + "%"), false); return 1; })
                        .then(class_2170.method_9244("percent", IntegerArgumentType.integer(0, 100))
                            .executes(ctx -> {
                                BotSettings.get().setMistakeChance(IntegerArgumentType.getInteger(ctx, "percent"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Mistake chance: " + BotSettings.get().getMistakeChance() + "%"), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("reactiondelay")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("reactiondelay: " + BotSettings.get().getReactionDelay() + " ticks"), false); return 1; })
                        .then(class_2170.method_9244("ticks", IntegerArgumentType.integer(0, 20))
                            .executes(ctx -> {
                                BotSettings.get().setReactionDelay(IntegerArgumentType.getInteger(ctx, "ticks"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Reaction delay: " + BotSettings.get().getReactionDelay() + " ticks"), true);
                                return 1;
                            })
                        )
                    )
                    
                    // === Weapon Settings ===
                    .then(class_2170.method_9247("prefersword")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("prefersword: " + BotSettings.get().isPreferSword()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setPreferSword(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Prefer sword: " + BotSettings.get().isPreferSword()), true);
                                return 1;
                            })
                        )
                    )
                    .then(class_2170.method_9247("shieldbreak")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("shieldbreak: " + BotSettings.get().isShieldBreakEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setShieldBreakEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Shield break: " + BotSettings.get().isShieldBreakEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings autoshield [true/false]
                    .then(class_2170.method_9247("autoshield")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("autoshield: " + BotSettings.get().isAutoShieldEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setAutoShieldEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Auto shield: " + BotSettings.get().isAutoShieldEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings autopotion [true/false]
                    .then(class_2170.method_9247("autopotion")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("autopotion: " + BotSettings.get().isAutoPotionEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setAutoPotionEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Auto potion: " + BotSettings.get().isAutoPotionEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings autototem [true/false]
                    .then(class_2170.method_9247("autototem")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("autototem: " + BotSettings.get().isAutoTotemEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setAutoTotemEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Auto totem: " + BotSettings.get().isAutoTotemEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings totempriority [true/false]
                    .then(class_2170.method_9247("totempriority")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("totempriority: " + BotSettings.get().isTotemPriority()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setTotemPriority(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Totem priority (don't replace with shield): " + BotSettings.get().isTotemPriority()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings retreat [true/false]
                    .then(class_2170.method_9247("retreat")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("retreat: " + BotSettings.get().isRetreatEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setRetreatEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Retreat enabled: " + BotSettings.get().isRetreatEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings autoeat [true/false]
                    .then(class_2170.method_9247("autoeat")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("autoeat: " + BotSettings.get().isAutoEatEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setAutoEatEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Auto eat enabled: " + BotSettings.get().isAutoEatEnabled()), true);
                                return 1;
                            })
                        )
                    )
                    
                    // /pvpbot settings automend [true/false]
                    .then(class_2170.method_9247("automend")
                        .executes(ctx -> { ctx.getSource().method_9226(() -> class_2561.method_43470("automend: " + BotSettings.get().isAutoMendEnabled()), false); return 1; })
                        .then(class_2170.method_9244("value", BoolArgumentType.bool())
                            .executes(ctx -> {
                                BotSettings.get().setAutoMendEnabled(BoolArgumentType.getBool(ctx, "value"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("Auto mend enabled: " + BotSettings.get().isAutoMendEnabled()), true);
                                return 1;
                            })
                        )
                    )
                )
                
                // /pvpbot attack <botname> <target> - СЃ РїРѕРґСЃРєР°Р·РєР°РјРё
                .then(class_2170.method_9247("attack")
                    .then(class_2170.method_9244("botname", StringArgumentType.word())
                        .suggests(BOT_SUGGESTIONS)
                        .then(class_2170.method_9244("target", StringArgumentType.word())
                            .suggests(TARGET_SUGGESTIONS)
                            .executes(ctx -> setAttackTarget(ctx.getSource(), 
                                StringArgumentType.getString(ctx, "botname"),
                                StringArgumentType.getString(ctx, "target")))
                        )
                    )
                )
                
                // /pvpbot stop <botname> - СЃ РїРѕРґСЃРєР°Р·РєР°РјРё
                .then(class_2170.method_9247("stop")
                    .then(class_2170.method_9244("botname", StringArgumentType.word())
                        .suggests(BOT_SUGGESTIONS)
                        .executes(ctx -> stopAttack(ctx.getSource(), StringArgumentType.getString(ctx, "botname")))
                    )
                )
                
                // /pvpbot target <botname> - РїРѕРєР°Р·Р°С‚СЊ С‚РµРєСѓС‰СѓСЋ С†РµР»СЊ
                .then(class_2170.method_9247("target")
                    .then(class_2170.method_9244("botname", StringArgumentType.word())
                        .suggests(BOT_SUGGESTIONS)
                        .executes(ctx -> showTarget(ctx.getSource(), StringArgumentType.getString(ctx, "botname")))
                    )
                )
                
                // /pvpbot inventory <botname> - РїРѕРєР°Р·Р°С‚СЊ РёРЅРІРµРЅС‚Р°СЂСЊ Р±РѕС‚Р°
                .then(class_2170.method_9247("inventory")
                    .then(class_2170.method_9244("botname", StringArgumentType.word())
                        .suggests(BOT_SUGGESTIONS)
                        .executes(ctx -> showInventory(ctx.getSource(), StringArgumentType.getString(ctx, "botname")))
                    )
                )
                
                // ============ РљРѕРјР°РЅРґС‹ С„СЂР°РєС†РёР№ ============
                .then(class_2170.method_9247("faction")
                    // /pvpbot faction list
                    .then(class_2170.method_9247("list")
                        .executes(ctx -> listFactions(ctx.getSource()))
                    )
                    // /pvpbot faction create <name>
                    .then(class_2170.method_9247("create")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(ctx -> createFaction(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                        )
                    )
                    // /pvpbot faction delete <name>
                    .then(class_2170.method_9247("delete")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .executes(ctx -> deleteFaction(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                        )
                    )
                    // /pvpbot faction add <faction> <player>
                    .then(class_2170.method_9247("add")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .then(class_2170.method_9244("player", StringArgumentType.word())
                                .suggests(TARGET_SUGGESTIONS)
                                .executes(ctx -> addToFaction(ctx.getSource(), 
                                    StringArgumentType.getString(ctx, "faction"),
                                    StringArgumentType.getString(ctx, "player")))
                            )
                        )
                    )
                    // /pvpbot faction remove <faction> <player>
                    .then(class_2170.method_9247("remove")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .then(class_2170.method_9244("player", StringArgumentType.word())
                                .executes(ctx -> removeFromFaction(ctx.getSource(), 
                                    StringArgumentType.getString(ctx, "faction"),
                                    StringArgumentType.getString(ctx, "player")))
                            )
                        )
                    )
                    // /pvpbot faction hostile <faction1> <faction2> [true/false]
                    .then(class_2170.method_9247("hostile")
                        .then(class_2170.method_9244("faction1", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .then(class_2170.method_9244("faction2", StringArgumentType.word())
                                .suggests(FACTION_SUGGESTIONS)
                                .executes(ctx -> setHostile(ctx.getSource(), 
                                    StringArgumentType.getString(ctx, "faction1"),
                                    StringArgumentType.getString(ctx, "faction2"),
                                    true))
                                .then(class_2170.method_9244("hostile", BoolArgumentType.bool())
                                    .executes(ctx -> setHostile(ctx.getSource(), 
                                        StringArgumentType.getString(ctx, "faction1"),
                                        StringArgumentType.getString(ctx, "faction2"),
                                        BoolArgumentType.getBool(ctx, "hostile")))
                                )
                            )
                        )
                    )
                    // /pvpbot faction info <faction>
                    .then(class_2170.method_9247("info")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .executes(ctx -> factionInfo(ctx.getSource(), StringArgumentType.getString(ctx, "faction")))
                        )
                    )
                    // /pvpbot faction addnear <faction> <radius> - РґРѕР±Р°РІРёС‚СЊ РІСЃРµС… Р±РѕС‚РѕРІ РІ СЂР°РґРёСѓСЃРµ
                    .then(class_2170.method_9247("addnear")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .then(class_2170.method_9244("radius", DoubleArgumentType.doubleArg(1.0, 10000.0))
                                .executes(ctx -> addNearbyBotsToFaction(ctx.getSource(), 
                                    StringArgumentType.getString(ctx, "faction"),
                                    DoubleArgumentType.getDouble(ctx, "radius")))
                            )
                        )
                    )
                    // /pvpbot faction addall <faction> - РґРѕР±Р°РІРёС‚СЊ Р’РЎР•РҐ Р±РѕС‚РѕРІ РІ С„СЂР°РєС†РёСЋ
                    .then(class_2170.method_9247("addall")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .executes(ctx -> addAllBotsToFaction(ctx.getSource(), 
                                StringArgumentType.getString(ctx, "faction")))
                        )
                    )
                    // /pvpbot faction give <faction> <item> [count] - РІС‹РґР°С‚СЊ РїСЂРµРґРјРµС‚ РІСЃРµР№ С„СЂР°РєС†РёРё
                    .then(class_2170.method_9247("give")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .then(class_2170.method_9244("item", StringArgumentType.greedyString())
                                .executes(ctx -> giveFactionItem(ctx.getSource(), 
                                    StringArgumentType.getString(ctx, "faction"),
                                    StringArgumentType.getString(ctx, "item")))
                            )
                        )
                    )
                    // /pvpbot faction attack <faction> <target> - РІСЃСЏ С„СЂР°РєС†РёСЏ Р°С‚Р°РєСѓРµС‚ С†РµР»СЊ
                    .then(class_2170.method_9247("attack")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .then(class_2170.method_9244("target", StringArgumentType.word())
                                .suggests(TARGET_SUGGESTIONS)
                                .executes(ctx -> factionAttack(ctx.getSource(), 
                                    StringArgumentType.getString(ctx, "faction"),
                                    StringArgumentType.getString(ctx, "target")))
                            )
                        )
                    )
                    // /pvpbot faction startpath <faction> <path> - запустить путь для всей фракции
                    .then(class_2170.method_9247("startpath")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .then(class_2170.method_9244("path", StringArgumentType.word())
                                .suggests(PATH_SUGGESTIONS)
                                .executes(ctx -> factionStartPath(ctx.getSource(), 
                                    StringArgumentType.getString(ctx, "faction"),
                                    StringArgumentType.getString(ctx, "path")))
                            )
                        )
                    )
                    // /pvpbot faction stoppath <faction> - остановить путь для всей фракции
                    .then(class_2170.method_9247("stoppath")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .executes(ctx -> factionStopPath(ctx.getSource(), 
                                StringArgumentType.getString(ctx, "faction")))
                        )
                    )
                )
                
                // /pvpbot settings viewdistance [5-128] - РґР°Р»СЊРЅРѕСЃС‚СЊ РІРёРґРёРјРѕСЃС‚Рё
                .then(class_2170.method_9247("settings")
                    .then(class_2170.method_9247("viewdistance")
                        .executes(ctx -> { 
                            ctx.getSource().method_9226(() -> class_2561.method_43470("viewdistance: " + BotSettings.get().getMaxTargetDistance()), false); 
                            return 1; 
                        })
                        .then(class_2170.method_9244("distance", DoubleArgumentType.doubleArg(5.0, 128.0))
                            .executes(ctx -> {
                                BotSettings.get().setMaxTargetDistance(DoubleArgumentType.getDouble(ctx, "distance"));
                                ctx.getSource().method_9226(() -> class_2561.method_43470("View distance: " + BotSettings.get().getMaxTargetDistance()), true);
                                return 1;
                            })
                        )
                    )
                )
                
                // ============ РљРѕРјР°РЅРґС‹ РєРёС‚РѕРІ ============
                // /pvpbot createkit <name> - СЃРѕР·РґР°С‚СЊ РєРёС‚ РёР· РёРЅРІРµРЅС‚Р°СЂСЏ РёРіСЂРѕРєР°
                .then(class_2170.method_9247("createkit")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .executes(ctx -> createKit(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                    )
                )
                
                // /pvpbot deletekit <name> - СѓРґР°Р»РёС‚СЊ РєРёС‚
                .then(class_2170.method_9247("deletekit")
                    .then(class_2170.method_9244("name", StringArgumentType.word())
                        .suggests(KIT_SUGGESTIONS)
                        .executes(ctx -> deleteKit(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                    )
                )
                
                // /pvpbot kits - СЃРїРёСЃРѕРє РєРёС‚РѕРІ
                .then(class_2170.method_9247("kits")
                    .executes(ctx -> listKits(ctx.getSource()))
                )
                
                // /pvpbot givekit <playername> <kitname> - РІС‹РґР°С‚СЊ РєРёС‚ РёРіСЂРѕРєСѓ РёР»Рё Р±РѕС‚Сѓ
                .then(class_2170.method_9247("givekit")
                    .then(class_2170.method_9244("playername", StringArgumentType.word())
                        .suggests(PLAYER_SUGGESTIONS)
                        .then(class_2170.method_9244("kitname", StringArgumentType.word())
                            .suggests(KIT_SUGGESTIONS)
                            .executes(ctx -> giveKitToPlayer(ctx.getSource(), 
                                StringArgumentType.getString(ctx, "playername"),
                                StringArgumentType.getString(ctx, "kitname")))
                        )
                    )
                )
                
                // /pvpbot faction givekit <faction> <kitname> - РІС‹РґР°С‚СЊ РєРёС‚ РІСЃРµР№ С„СЂР°РєС†РёРё
                .then(class_2170.method_9247("faction")
                    .then(class_2170.method_9247("givekit")
                        .then(class_2170.method_9244("faction", StringArgumentType.word())
                            .suggests(FACTION_SUGGESTIONS)
                            .then(class_2170.method_9244("kitname", StringArgumentType.word())
                                .suggests(KIT_SUGGESTIONS)
                                .executes(ctx -> giveKitToFaction(ctx.getSource(), 
                                    StringArgumentType.getString(ctx, "faction"),
                                    StringArgumentType.getString(ctx, "kitname")))
                            )
                        )
                    )
                )
                
                // /pvpbot updatestats - РѕС‚РїСЂР°РІРёС‚СЊ СЃС‚Р°С‚РёСЃС‚РёРєСѓ СЃРµР№С‡Р°СЃ (РґР»СЏ РѕС‚Р»Р°РґРєРё)
                
                // /pvpbot path - система путей для патрулирования
                .then(class_2170.method_9247("path")
                    .then(class_2170.method_9247("create")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(ctx -> createPath(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                        )
                    )
                    .then(class_2170.method_9247("delete")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .executes(ctx -> deletePath(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                        )
                    )
                    .then(class_2170.method_9247("addpoint")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .executes(ctx -> addPathPoint(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                        )
                    )
                    .then(class_2170.method_9247("removepoint")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .executes(ctx -> removeLastPathPoint(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                            .then(class_2170.method_9244("index", IntegerArgumentType.integer(0))
                                .executes(ctx -> removePathPoint(ctx.getSource(), StringArgumentType.getString(ctx, "name"), IntegerArgumentType.getInteger(ctx, "index")))
                            )
                        )
                    )
                    .then(class_2170.method_9247("clear")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .executes(ctx -> clearPath(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                        )
                    )
                    .then(class_2170.method_9247("loop")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .then(class_2170.method_9244("value", BoolArgumentType.bool())
                                .executes(ctx -> setPathLoop(ctx.getSource(), StringArgumentType.getString(ctx, "name"), BoolArgumentType.getBool(ctx, "value")))
                            )
                        )
                    )
                    .then(class_2170.method_9247("attack")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .then(class_2170.method_9244("value", BoolArgumentType.bool())
                                .executes(ctx -> setPathAttack(ctx.getSource(), StringArgumentType.getString(ctx, "name"), BoolArgumentType.getBool(ctx, "value")))
                            )
                        )
                    )
                    .then(class_2170.method_9247("start")
                        .then(class_2170.method_9244("bot", StringArgumentType.word())
                            .suggests(BOT_SUGGESTIONS)
                            .then(class_2170.method_9244("path", StringArgumentType.word())
                                .suggests(PATH_SUGGESTIONS)
                                .executes(ctx -> startPathFollowing(ctx.getSource(), StringArgumentType.getString(ctx, "bot"), StringArgumentType.getString(ctx, "path")))
                            )
                        )
                    )
                    .then(class_2170.method_9247("stop")
                        .then(class_2170.method_9244("bot", StringArgumentType.word())
                            .suggests(BOT_SUGGESTIONS)
                            .executes(ctx -> stopPathFollowing(ctx.getSource(), StringArgumentType.getString(ctx, "bot")))
                        )
                    )
                    .then(class_2170.method_9247("list")
                        .executes(ctx -> listPaths(ctx.getSource()))
                    )
                    .then(class_2170.method_9247("show")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .then(class_2170.method_9244("visible", BoolArgumentType.bool())
                                .executes(ctx -> showPath(ctx.getSource(), StringArgumentType.getString(ctx, "name"), BoolArgumentType.getBool(ctx, "visible")))
                            )
                        )
                    )
                    .then(class_2170.method_9247("info")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .executes(ctx -> pathInfo(ctx.getSource(), StringArgumentType.getString(ctx, "name")))
                        )
                    )
                    // /pvpbot path distribute <path> - распределить ботов по пути
                    .then(class_2170.method_9247("distribute")
                        .then(class_2170.method_9244("path", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .executes(ctx -> distributeBotsOnPath(ctx.getSource(), StringArgumentType.getString(ctx, "path")))
                        )
                    )
                    // /pvpbot path startnear <path> <radius> - запустить путь для ботов в радиусе
                    .then(class_2170.method_9247("startnear")
                        .then(class_2170.method_9244("path", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .then(class_2170.method_9244("radius", DoubleArgumentType.doubleArg(1.0))
                                .executes(ctx -> startPathNear(ctx.getSource(), StringArgumentType.getString(ctx, "path"), DoubleArgumentType.getDouble(ctx, "radius")))
                            )
                        )
                    )
                    // /pvpbot path stopall <path> - остановить всех ботов на пути
                    .then(class_2170.method_9247("stopall")
                        .then(class_2170.method_9244("path", StringArgumentType.word())
                            .suggests(PATH_SUGGESTIONS)
                            .executes(ctx -> stopAllOnPath(ctx.getSource(), StringArgumentType.getString(ctx, "path")))
                        )
                    )
                )
                .then(class_2170.method_9247("updatestats")
                    .executes(ctx -> updateStats(ctx.getSource()))
                )
        );
    }
    
    private static int setAttackTarget(class_2168 source, String botName, String targetName) {
        if (!BotManager.getAllBots().contains(botName)) {
            source.method_9213(class_2561.method_43470("Bot '" + botName + "' not found!"));
            return 0;
        }
        
        BotCombat.setTarget(botName, targetName);
        source.method_9226(() -> class_2561.method_43470("Bot '" + botName + "' now attacking '" + targetName + "'"), true);
        return 1;
    }
    
    private static int stopAttack(class_2168 source, String botName) {
        if (!BotManager.getAllBots().contains(botName)) {
            source.method_9213(class_2561.method_43470("Bot '" + botName + "' not found!"));
            return 0;
        }
        
        BotCombat.clearTarget(botName);
        source.method_9226(() -> class_2561.method_43470("Bot '" + botName + "' stopped attacking"), true);
        return 1;
    }
    
    private static int showTarget(class_2168 source, String botName) {
        if (!BotManager.getAllBots().contains(botName)) {
            source.method_9213(class_2561.method_43470("Bot '" + botName + "' not found!"));
            return 0;
        }
        
        var target = BotCombat.getTarget(botName);
        if (target != null) {
            source.method_9226(() -> class_2561.method_43470("Bot '" + botName + "' target: " + target.method_5477().getString()), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("Bot '" + botName + "' has no target"), false);
        }
        return 1;
    }


    private static int spawnBot(class_2168 source, String name) {
        // РџСЂРѕРІРµСЂСЏРµРј СЃСѓС‰РµСЃС‚РІСѓРµС‚ Р»Рё СЂРµР°Р»СЊРЅС‹Р№ РёРіСЂРѕРє СЃ С‚Р°РєРёРј РЅРёРєРѕРј
        var server = source.method_9211();
        var existingPlayer = server.method_3760().method_14566(name);
        if (existingPlayer != null && !BotManager.getAllBots().contains(name)) {
            source.method_9213(class_2561.method_43470("Cannot create bot '" + name + "': a real player with this name is online!"));
            return 0;
        }
        
        if (BotManager.spawnBot(server, name, source)) {
            source.method_9226(() -> class_2561.method_43470("PvP Bot '" + name + "' spawned!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to spawn bot '" + name + "' (bot already exists or name is taken)"));
            return 0;
        }
    }
    
    private static int massSpawnBots(class_2168 source, int count) {
        var server = source.method_9211();
        final int[] spawned = {0};
        final int[] current = {0};
        
        source.method_9226(() -> class_2561.method_43470("Spawning " + count + " bots "), false);
        
        // РЎРїР°РІРЅРёРј Р±РѕС‚РѕРІ СЃ Р·Р°РґРµСЂР¶РєРѕР№ С‡РµСЂРµР· scheduled tasks
        scheduleSpawn(server, source, count, spawned, current);
        
        return 1;
    }
    
    private static void scheduleSpawn(net.minecraft.server.MinecraftServer server, class_2168 source, int total, int[] spawned, int[] current) {
        if (current[0] >= total) {
            source.method_9226(() -> class_2561.method_43470("Finished! Spawned " + spawned[0] + " bots."), true);
            return;
        }
        
        // РЎРїР°РІРЅРёРј РѕРґРЅРѕРіРѕ Р±РѕС‚Р°
        String name = BotNameGenerator.generateUniqueName();
        if (BotManager.spawnBot(server, name, source)) {
            spawned[0]++;
        }
        current[0]++;
        
        // РџР»Р°РЅРёСЂСѓРµРј СЃР»РµРґСѓСЋС‰РёР№ СЃРїР°РІРЅ С‡РµСЂРµР· 5 С‚РёРєРѕРІ
        server.execute(() -> {
            // РСЃРїРѕР»СЊР·СѓРµРј РїСЂРѕСЃС‚СѓСЋ Р·Р°РґРµСЂР¶РєСѓ С‡РµСЂРµР· С‚РёРєРё СЃРµСЂРІРµСЂР°
            final int[] delay = {0};
            server.execute(new Runnable() {
                @Override
                public void run() {
                    delay[0]++;
                    if (delay[0] < 5) {
                        server.execute(this);
                    } else {
                        scheduleSpawn(server, source, total, spawned, current);
                    }
                }
            });
        });
    }

    private static int removeBot(class_2168 source, String name) {
        if (BotManager.removeBot(source.method_9211(), name, source)) {
            source.method_9226(() -> class_2561.method_43470("Bot '" + name + "' removed!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Bot '" + name + "' not found!"));
            return 0;
        }
    }

    private static int removeAllBots(class_2168 source) {
        int count = BotManager.getBotCount();
        BotManager.removeAllBots(source.method_9211(), source);
        source.method_9226(() -> class_2561.method_43470("Removed " + count + " bots"), true);
        return count;
    }

    private static int listBots(class_2168 source) {
        var bots = BotManager.getAllBots();
        
        if (bots.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No active PvP bots"), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("Active PvP bots (" + bots.size() + "):"), false);
            for (String botName : bots) {
                source.method_9226(() -> class_2561.method_43470(" - " + botName), false);
            }
        }
        return bots.size();
    }
    
    private static int syncBots(class_2168 source) {
        var server = source.method_9211();
        int beforeCount = BotManager.getAllBots().size();
        
        // РџРѕРєР°Р·С‹РІР°РµРј РІСЃРµС… РёРіСЂРѕРєРѕРІ Рё РёС… РєР»Р°СЃСЃС‹ РґР»СЏ РѕС‚Р»Р°РґРєРё
        source.method_9226(() -> class_2561.method_43470("=== Players on server ==="), false);
        for (var player : server.method_3760().method_14571()) {
            String name = player.method_5477().getString();
            String className = player.getClass().getName();
            boolean inList = BotManager.getAllBots().contains(name);
            source.method_9226(() -> class_2561.method_43470(" - " + name + " [" + className + "] " + (inList ? "(in list)" : "(NOT in list)")), false);
        }
        
        // РЎРёРЅС…СЂРѕРЅРёР·РёСЂСѓРµРј
        BotManager.syncBots(server);
        
        int afterCount = BotManager.getAllBots().size();
        int added = afterCount - beforeCount;
        
        source.method_9226(() -> class_2561.method_43470("Synced! Added " + added + " bots. Total: " + afterCount), true);
        return added;
    }
    
    private static int syncBot(class_2168 source, String name) {
        var server = source.method_9211();
        
        // РџСЂРѕРІРµСЂСЏРµРј РµСЃС‚СЊ Р»Рё С‚Р°РєРѕР№ РёРіСЂРѕРє
        class_3222 player = server.method_3760().method_14566(name);
        if (player == null) {
            source.method_9226(() -> class_2561.method_43470("Player " + name + " not found on server!"), false);
            return 0;
        }
        
        // РџРѕРєР°Р·С‹РІР°РµРј РёРЅС„РѕСЂРјР°С†РёСЋ РѕР± РёРіСЂРѕРєРµ
        String className = player.getClass().getName();
        boolean inList = BotManager.getAllBots().contains(name);
        source.method_9226(() -> class_2561.method_43470("Player: " + name), false);
        source.method_9226(() -> class_2561.method_43470("Class: " + className), false);
        source.method_9226(() -> class_2561.method_43470("In bot list: " + inList), false);
        
        // РЎРёРЅС…СЂРѕРЅРёР·РёСЂСѓРµРј
        boolean added = BotManager.syncBot(server, name);
        
        if (added) {
            source.method_9226(() -> class_2561.method_43470("Successfully added " + name + " to bot list!"), true);
            return 1;
        } else if (inList) {
            source.method_9226(() -> class_2561.method_43470(name + " is already in bot list!"), false);
            return 0;
        } else {
            source.method_9226(() -> class_2561.method_43470(name + " is not a fake player (HeroBot bot)!"), false);
            return 0;
        }
    }

    private static int openSettingsGui(class_2168 source) {
        try {
            class_3222 player = source.method_44023();
            if (player == null) {
                source.method_9213(class_2561.method_43470("This command must be run by a player!"));
                return 0;
            }
            
            SettingsGui gui = new SettingsGui(player);
            gui.open();
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("Failed to open settings GUI: " + e.getMessage()));
            e.printStackTrace();
            return 0;
        }
    }

    private static int showSettings(class_2168 source) {
        BotSettings s = BotSettings.get();
        source.method_9226(() -> class_2561.method_43470("=== Equipment Settings ==="), false);
        source.method_9226(() -> class_2561.method_43470("autoarmor: " + s.isAutoEquipArmor()), false);
        source.method_9226(() -> class_2561.method_43470("autoweapon: " + s.isAutoEquipWeapon()), false);
        source.method_9226(() -> class_2561.method_43470("droparmor: " + s.isDropWorseArmor()), false);
        source.method_9226(() -> class_2561.method_43470("dropweapon: " + s.isDropWorseWeapons()), false);
        source.method_9226(() -> class_2561.method_43470("dropdistance: " + s.getDropDistance()), false);
        source.method_9226(() -> class_2561.method_43470("interval: " + s.getCheckInterval() + " ticks"), false);
        source.method_9226(() -> class_2561.method_43470("minarmorlevel: " + s.getMinArmorLevel()), false);
        
        source.method_9226(() -> class_2561.method_43470("=== Combat Settings ==="), false);
        source.method_9226(() -> class_2561.method_43470("combat: " + s.isCombatEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("revenge: " + s.isRevengeEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("autotarget: " + s.isAutoTargetEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("targetplayers: " + s.isTargetPlayers()), false);
        source.method_9226(() -> class_2561.method_43470("targetmobs: " + s.isTargetHostileMobs()), false);
        source.method_9226(() -> class_2561.method_43470("targetbots: " + s.isTargetOtherBots()), false);
        source.method_9226(() -> class_2561.method_43470("criticals: " + s.isCriticalsEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("ranged: " + s.isRangedEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("mace: " + s.isMaceEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("attackcooldown: " + s.getAttackCooldown() + " ticks"), false);
        source.method_9226(() -> class_2561.method_43470("meleerange: " + s.getMeleeRange()), false);
        source.method_9226(() -> class_2561.method_43470("movespeed: " + s.getMoveSpeed()), false);
        
        source.method_9226(() -> class_2561.method_43470("=== Utilities ==="), false);
        source.method_9226(() -> class_2561.method_43470("autototem: " + s.isAutoTotemEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("totempriority: " + s.isTotemPriority() + " (don't replace totem with shield)"), false);
        source.method_9226(() -> class_2561.method_43470("autoshield: " + s.isAutoShieldEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("autopotion: " + s.isAutoPotionEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("shieldbreak: " + s.isShieldBreakEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("prefersword: " + s.isPreferSword()), false);
        
        source.method_9226(() -> class_2561.method_43470("=== Navigation Settings ==="), false);
        source.method_9226(() -> class_2561.method_43470("bhop: " + s.isBhopEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("bhopcooldown: " + s.getBhopCooldown() + " ticks"), false);
        source.method_9226(() -> class_2561.method_43470("jumpboost: " + s.getJumpBoost()), false);
        source.method_9226(() -> class_2561.method_43470("idle: " + s.isIdleWanderEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("idleradius: " + s.getIdleWanderRadius()), false);
        source.method_9226(() -> class_2561.method_43470("=== Factions & Mistakes ==="), false);
        source.method_9226(() -> class_2561.method_43470("factions: " + s.isFactionsEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("friendlyfire: " + s.isFriendlyFireEnabled()), false);
        source.method_9226(() -> class_2561.method_43470("misschance: " + s.getMissChance() + "%"), false);
        source.method_9226(() -> class_2561.method_43470("mistakechance: " + s.getMistakeChance() + "%"), false);
        source.method_9226(() -> class_2561.method_43470("reactiondelay: " + s.getReactionDelay() + " ticks"), false);
        return 1;
    }
    
    // ============ РљРѕРјР°РЅРґС‹ С„СЂР°РєС†РёР№ ============
    
    private static int listFactions(class_2168 source) {
        var factions = BotFaction.getAllFactions();
        if (factions.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No factions created"), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("Factions (" + factions.size() + "):"), false);
            for (String faction : factions) {
                var members = BotFaction.getMembers(faction);
                var enemies = BotFaction.getHostileFactions(faction);
                source.method_9226(() -> class_2561.method_43470(" - " + faction + " (" + members.size() + " members, " + enemies.size() + " enemies)"), false);
            }
        }
        return factions.size();
    }
    
    private static int createFaction(class_2168 source, String name) {
        if (BotFaction.createFaction(name)) {
            source.method_9226(() -> class_2561.method_43470("Faction '" + name + "' created!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Faction '" + name + "' already exists!"));
            return 0;
        }
    }
    
    private static int deleteFaction(class_2168 source, String name) {
        if (BotFaction.deleteFaction(name)) {
            source.method_9226(() -> class_2561.method_43470("Faction '" + name + "' deleted!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Faction '" + name + "' not found!"));
            return 0;
        }
    }
    
    private static int addToFaction(class_2168 source, String faction, String player) {
        if (BotFaction.addMember(faction, player)) {
            source.method_9226(() -> class_2561.method_43470("Added '" + player + "' to faction '" + faction + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
    }
    
    private static int removeFromFaction(class_2168 source, String faction, String player) {
        if (BotFaction.removeMember(faction, player)) {
            source.method_9226(() -> class_2561.method_43470("Removed '" + player + "' from faction '" + faction + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to remove '" + player + "' from faction '" + faction + "'"));
            return 0;
        }
    }
    
    private static int setHostile(class_2168 source, String faction1, String faction2, boolean hostile) {
        if (BotFaction.setHostile(faction1, faction2, hostile)) {
            if (hostile) {
                source.method_9226(() -> class_2561.method_43470("Factions '" + faction1 + "' and '" + faction2 + "' are now hostile!"), true);
            } else {
                source.method_9226(() -> class_2561.method_43470("Factions '" + faction1 + "' and '" + faction2 + "' are now neutral"), true);
            }
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("One or both factions not found, or same faction!"));
            return 0;
        }
    }
    
    private static int factionInfo(class_2168 source, String faction) {
        var members = BotFaction.getMembers(faction);
        var enemies = BotFaction.getHostileFactions(faction);
        
        if (members.isEmpty() && enemies.isEmpty() && !BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        
        source.method_9226(() -> class_2561.method_43470("=== Faction: " + faction + " ==="), false);
        source.method_9226(() -> class_2561.method_43470("Members (" + members.size() + "): " + String.join(", ", members)), false);
        source.method_9226(() -> class_2561.method_43470("Hostile to (" + enemies.size() + "): " + String.join(", ", enemies)), false);
        return 1;
    }
    
    private static int addNearbyBotsToFaction(class_2168 source, String faction, double radius) {
        if (!BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        
        var entity = source.method_9228();
        if (entity == null) {
            source.method_9213(class_2561.method_43470("This command must be run by a player!"));
            return 0;
        }
        
        int count = 0;
        var allBots = BotManager.getAllBots();
        var server = source.method_9211();
        
        for (String botName : allBots) {
            var bot = server.method_3760().method_14566(botName);
            if (bot != null && bot.method_5739(entity) <= radius) {
                BotFaction.addMember(faction, botName);
                count++;
            }
        }
        
        final int added = count;
        source.method_9226(() -> class_2561.method_43470("Added " + added + " bots to faction '" + faction + "'"), true);
        return count;
    }
    
    private static int addAllBotsToFaction(class_2168 source, String faction) {
        if (!BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        
        var allBots = BotManager.getAllBots();
        int count = 0;
        
        for (String botName : allBots) {
            BotFaction.addMember(faction, botName);
            count++;
        }
        
        final int added = count;
        source.method_9226(() -> class_2561.method_43470("Added " + added + " bots to faction '" + faction + "'"), true);
        return count;
    }
    
    private static int showInventory(class_2168 source, String botName) {
        if (!BotManager.getAllBots().contains(botName)) {
            source.method_9213(class_2561.method_43470("Bot '" + botName + "' not found!"));
            return 0;
        }
        
        var bot = source.method_9211().method_3760().method_14566(botName);
        if (bot == null) {
            source.method_9213(class_2561.method_43470("Bot '" + botName + "' not online!"));
            return 0;
        }
        
        // Р•СЃР»Рё InvView СѓСЃС‚Р°РЅРѕРІР»РµРЅ - РёСЃРїРѕР»СЊР·СѓРµРј РµРіРѕ GUI
        if (HAS_INVVIEW) {
            try {
                return openInvViewGui(source, bot);
            } catch (Exception e) {
                source.method_9213(class_2561.method_43470("Failed to open InvView GUI: " + e.getMessage()));
                return 0;
            }
        }
        
        // Р•СЃР»Рё InvView РЅРµ СѓСЃС‚Р°РЅРѕРІР»РµРЅ - РїРѕРєР°Р·С‹РІР°РµРј СЃРѕРѕР±С‰РµРЅРёРµ
        source.method_9213(class_2561.method_43470("InvView mod is not installed!"));
        source.method_9226(() -> class_2561.method_43470("Please install InvView to view bot inventories: https://modrinth.com/mod/invview"), false);
        return 0;
    }
    
    /**
     * РћС‚РєСЂС‹РІР°РµС‚ GUI InvView С‡РµСЂРµР· СЂРµС„Р»РµРєСЃРёСЋ (С‡С‚РѕР±С‹ РЅРµ Р±С‹Р»Рѕ Р¶РµСЃС‚РєРѕР№ Р·Р°РІРёСЃРёРјРѕСЃС‚Рё)
     */
    private static int openInvViewGui(class_2168 source, class_3222 targetPlayer) throws Exception {
        class_3222 viewer = source.method_44023();
        if (viewer == null) {
            source.method_9213(class_2561.method_43470("This command must be run by a player!"));
            return 0;
        }
        
        // РСЃРїРѕР»СЊР·СѓРµРј СЂРµС„Р»РµРєСЃРёСЋ С‚РѕР»СЊРєРѕ РґР»СЏ РєР»Р°СЃСЃРѕРІ InvView
        Class<?> simpleGuiClass = Class.forName("eu.pb4.sgui.api.gui.SimpleGui");
        Class<?> savingGuiClass = Class.forName("us.potatoboy.invview.gui.SavingPlayerDataGui");
        
        // РџРѕР»СѓС‡Р°РµРј ScreenHandlerType.GENERIC_9X5 РЅР°РїСЂСЏРјСѓСЋ
        Object screenHandlerType = net.minecraft.class_3917.field_18667;
        
        // new SavingPlayerDataGui(ScreenHandlerType.GENERIC_9X5, viewer, targetPlayer)
        Object gui = savingGuiClass.getConstructor(
                net.minecraft.class_3917.class, 
                class_3222.class, 
                class_3222.class)
                .newInstance(screenHandlerType, viewer, targetPlayer);
        
        // gui.setTitle(targetPlayer.getName())
        Method setTitleMethod = simpleGuiClass.getMethod("setTitle", class_2561.class);
        setTitleMethod.invoke(gui, targetPlayer.method_5477());
        
        // Р”РѕР±Р°РІР»СЏРµРј СЃР»РѕС‚С‹ РёРЅРІРµРЅС‚Р°СЂСЏ (СЃ РІРѕР·РјРѕР¶РЅРѕСЃС‚СЊСЋ СЂРµРґР°РєС‚РёСЂРѕРІР°РЅРёСЏ)
        Method setSlotRedirectMethod = simpleGuiClass.getMethod("setSlotRedirect", int.class, net.minecraft.class_1735.class);
        var inventory = targetPlayer.method_31548();
        
        for (int i = 0; i < inventory.method_5439(); i++) {
            // new Slot(inventory, i, 0, 0) - РѕР±С‹С‡РЅС‹Р№ СЃР»РѕС‚ СЃ РІРѕР·РјРѕР¶РЅРѕСЃС‚СЊСЋ СЂРµРґР°РєС‚РёСЂРѕРІР°РЅРёСЏ
            net.minecraft.class_1735 slot = new net.minecraft.class_1735(inventory, i, 0, 0);
            setSlotRedirectMethod.invoke(gui, i, slot);
        }
        
        // gui.open()
        Method openMethod = simpleGuiClass.getMethod("open");
        openMethod.invoke(gui);
        
        return 1;
    }
    
    private static int giveFactionItem(class_2168 source, String faction, String itemCommand) {
        if (!BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        
        var members = BotFaction.getMembers(faction);
        var server = source.method_9211();
        int count = 0;
        
        for (String memberName : members) {
            // РСЃРїРѕР»СЊР·СѓРµРј РєРѕРјР°РЅРґСѓ give РґР»СЏ РєР°Р¶РґРѕРіРѕ С‡Р»РµРЅР° С„СЂР°РєС†РёРё
            try {
                server.method_3734().method_9235().execute(
                    "give " + memberName + " " + itemCommand,
                    server.method_3739()
                );
                count++;
            } catch (Exception e) {
                // РРіРЅРѕСЂРёСЂСѓРµРј РѕС€РёР±РєРё (РёРіСЂРѕРє РјРѕР¶РµС‚ Р±С‹С‚СЊ РѕС„С„Р»Р°Р№РЅ)
            }
        }
        
        final int given = count;
        source.method_9226(() -> class_2561.method_43470("Gave items to " + given + " members of faction '" + faction + "'"), true);
        return count;
    }
    
    private static int factionAttack(class_2168 source, String faction, String targetName) {
        if (!BotFaction.getAllFactions().contains(faction)) {
            source.method_9213(class_2561.method_43470("Faction '" + faction + "' not found!"));
            return 0;
        }
        
        var members = BotFaction.getMembers(faction);
        int count = 0;
        
        for (String memberName : members) {
            // РўРѕР»СЊРєРѕ Р±РѕС‚С‹ РјРѕРіСѓС‚ Р°С‚Р°РєРѕРІР°С‚СЊ
            if (BotManager.getAllBots().contains(memberName)) {
                BotCombat.setTarget(memberName, targetName);
                count++;
            }
        }
        
        final int attacking = count;
        source.method_9226(() -> class_2561.method_43470("Faction '" + faction + "' (" + attacking + " bots) attacking " + targetName + "!"), true);
        return count;
    }
    
    // ============ РљРѕРјР°РЅРґС‹ РєРёС‚РѕРІ ============
    
    private static int createKit(class_2168 source, String kitName) {
        var player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("This command must be run by a player!"));
            return 0;
        }
        
        if (BotKits.kitExists(kitName)) {
            source.method_9213(class_2561.method_43470("Kit '" + kitName + "' already exists!"));
            return 0;
        }
        
        if (BotKits.createKit(kitName, player)) {
            source.method_9226(() -> class_2561.method_43470("Kit '" + kitName + "' created from your inventory!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to create kit (empty inventory?)"));
            return 0;
        }
    }
    
    private static int deleteKit(class_2168 source, String kitName) {
        if (BotKits.deleteKit(kitName)) {
            source.method_9226(() -> class_2561.method_43470("Kit '" + kitName + "' deleted!"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Kit '" + kitName + "' not found!"));
            return 0;
        }
    }
    
    private static int listKits(class_2168 source) {
        var kits = BotKits.getKitNames();
        if (kits.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("No kits created. Use /pvpbot createkit <name> to create one."), false);
        } else {
            source.method_9226(() -> class_2561.method_43470("Kits (" + kits.size() + "): " + String.join(", ", kits)), false);
        }
        return 1;
    }
    
    private static int giveKitToPlayer(class_2168 source, String playerName, String kitName) {
        if (!BotKits.kitExists(kitName)) {
            source.method_9213(class_2561.method_43470("Kit '" + kitName + "' not found!"));
            return 0;
        }
        
        // РС‰РµРј РёРіСЂРѕРєР° РЅР° СЃРµСЂРІРµСЂРµ (Р±РѕС‚ РёР»Рё РѕР±С‹С‡РЅС‹Р№ РёРіСЂРѕРє)
        var player = source.method_9211().method_3760().method_14566(playerName);
        if (player == null) {
            source.method_9213(class_2561.method_43470("Player '" + playerName + "' not found!"));
            return 0;
        }
        
        if (BotKits.giveKit(kitName, player)) {
            source.method_9226(() -> class_2561.method_43470("Gave kit '" + kitName + "' to '" + playerName + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("Failed to give kit!"));
            return 0;
        }
    }
    
    private static int giveKitToFaction(class_2168 source, String factionName, String kitName) {
        if (!BotFaction.getAllFactions().contains(factionName)) {
            source.method_9213(class_2561.method_43470("Faction '" + factionName + "' not found!"));
            return 0;
        }
        
        if (!BotKits.kitExists(kitName)) {
            source.method_9213(class_2561.method_43470("Kit '" + kitName + "' not found!"));
            return 0;
        }
        
        var members = BotFaction.getMembers(factionName);
        if (members == null || members.isEmpty()) {
            source.method_9213(class_2561.method_43470("Faction '" + factionName + "' has no members!"));
            return 0;
        }
        
        int count = 0;
        for (String memberName : members) {
            // РџСЂРѕРІРµСЂСЏРµРј С‡С‚Рѕ СЌС‚Рѕ Р±РѕС‚
            if (BotManager.getAllBots().contains(memberName)) {
                var bot = BotManager.getBot(source.method_9211(), memberName);
                if (bot != null && BotKits.giveKit(kitName, bot)) {
                    count++;
                }
            }
        }
        
        final int given = count;
        source.method_9226(() -> class_2561.method_43470("Gave kit '" + kitName + "' to " + given + " bots in faction '" + factionName + "'"), true);
        return 1;
    }
    
    /**
     * РћС‚РєСЂС‹РІР°РµС‚ С‚РµСЃС‚РѕРІРѕРµ РјРµРЅСЋ СЃ РїСЂРёРјРµСЂР°РјРё sgui
     */
    private static int openTestMenu(class_2168 source) {
        try {
            class_3222 player = source.method_44023();
            if (player == null) {
                source.method_9213(class_2561.method_43470("This command must be run by a player!"));
                return 0;
            }
            
            // РћС‚РєСЂС‹РІР°РµРј РіР»Р°РІРЅРѕРµ РјРµРЅСЋ
            org.stepan1411.pvp_bot.gui.BotMenuGui.openMainMenu(player);
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("Failed to open menu: " + e.getMessage()));
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * РћС‚РїСЂР°РІР»СЏРµС‚ СЃС‚Р°С‚РёСЃС‚РёРєСѓ РЅР° СЃРµСЂРІРµСЂ (РґР»СЏ РѕС‚Р»Р°РґРєРё)
     */
    private static int updateStats(class_2168 source) {
        try {
            StatsReporter.sendStats();
            source.method_9226(() -> class_2561.method_43470("Statistics sent to server!"), true);
            return 1;
        } catch (Exception e) {
            source.method_9213(class_2561.method_43470("Failed to send statistics: " + e.getMessage()));
            return 0;
        }
    }
    
    // ============ Debug Commands ============
    
    private static int toggleDebugPath(class_2168 source, String botName) {
        var settings = BotDebug.getSettings(botName);
        boolean newValue = !settings.pathVisualization;
        BotDebug.setPathVisualization(botName, newValue);
        source.method_9226(() -> class_2561.method_43470("Path visualization for " + botName + ": " + newValue), true);
        return newValue ? 1 : 0;
    }
    
    private static int setDebugPath(class_2168 source, String botName, boolean enabled) {
        BotDebug.setPathVisualization(botName, enabled);
        source.method_9226(() -> class_2561.method_43470("Path visualization for " + botName + ": " + enabled), true);
        return enabled ? 1 : 0;
    }
    
    private static int toggleDebugTarget(class_2168 source, String botName) {
        var settings = BotDebug.getSettings(botName);
        boolean newValue = !settings.targetVisualization;
        BotDebug.setTargetVisualization(botName, newValue);
        source.method_9226(() -> class_2561.method_43470("Target visualization for " + botName + ": " + newValue), true);
        return newValue ? 1 : 0;
    }
    
    private static int setDebugTarget(class_2168 source, String botName, boolean enabled) {
        BotDebug.setTargetVisualization(botName, enabled);
        source.method_9226(() -> class_2561.method_43470("Target visualization for " + botName + ": " + enabled), true);
        return enabled ? 1 : 0;
    }
    
    private static int toggleDebugCombat(class_2168 source, String botName) {
        var settings = BotDebug.getSettings(botName);
        boolean newValue = !settings.combatInfo;
        BotDebug.setCombatInfo(botName, newValue);
        source.method_9226(() -> class_2561.method_43470("Combat info for " + botName + ": " + newValue), true);
        return newValue ? 1 : 0;
    }
    
    private static int setDebugCombat(class_2168 source, String botName, boolean enabled) {
        BotDebug.setCombatInfo(botName, enabled);
        source.method_9226(() -> class_2561.method_43470("Combat info for " + botName + ": " + enabled), true);
        return enabled ? 1 : 0;
    }
    
    private static int toggleDebugNavigation(class_2168 source, String botName) {
        var settings = BotDebug.getSettings(botName);
        boolean newValue = !settings.navigationInfo;
        BotDebug.setNavigationInfo(botName, newValue);
        source.method_9226(() -> class_2561.method_43470("Navigation info for " + botName + ": " + newValue), true);
        return newValue ? 1 : 0;
    }
    
    private static int setDebugNavigation(class_2168 source, String botName, boolean enabled) {
        BotDebug.setNavigationInfo(botName, enabled);
        source.method_9226(() -> class_2561.method_43470("Navigation info for " + botName + ": " + enabled), true);
        return enabled ? 1 : 0;
    }
    
    private static int toggleDebugAll(class_2168 source, String botName) {
        var settings = BotDebug.getSettings(botName);
        boolean newValue = !settings.isAnyEnabled();
        if (newValue) {
            BotDebug.enableAll(botName);
        } else {
            BotDebug.disableAll(botName);
        }
        source.method_9226(() -> class_2561.method_43470("All debug modes for " + botName + ": " + newValue), true);
        return newValue ? 1 : 0;
    }
    
    private static int setDebugAll(class_2168 source, String botName, boolean enabled) {
        if (enabled) {
            BotDebug.enableAll(botName);
        } else {
            BotDebug.disableAll(botName);
        }
        source.method_9226(() -> class_2561.method_43470("All debug modes for " + botName + ": " + enabled), true);
        return enabled ? 1 : 0;
    }
    
    private static int showDebugStatus(class_2168 source, String botName) {
        var settings = BotDebug.getSettings(botName);
        source.method_9226(() -> class_2561.method_43470("=== Debug Status for " + botName + " ==="), false);
        source.method_9226(() -> class_2561.method_43470("Path visualization: " + settings.pathVisualization), false);
        source.method_9226(() -> class_2561.method_43470("Target visualization: " + settings.targetVisualization), false);
        source.method_9226(() -> class_2561.method_43470("Combat info: " + settings.combatInfo), false);
        source.method_9226(() -> class_2561.method_43470("Navigation info: " + settings.navigationInfo), false);
        return 1;
    }
    
    // ========== PATH COMMANDS ==========
    
    private static int createPath(class_2168 source, String name) {
        if (org.stepan1411.pvp_bot.bot.BotPath.createPath(name)) {
            // Автоматически включаем визуализацию
            org.stepan1411.pvp_bot.bot.BotPath.setPathVisible(name, true);
            source.method_9226(() -> class_2561.method_43470("§aPath '" + name + "' created"), true);
            source.method_9226(() -> class_2561.method_43470("§7Visualization enabled. To disable: §e/pvpbot path show " + name + " false"), false);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cPath '" + name + "' already exists"));
            return 0;
        }
    }
    
    private static int deletePath(class_2168 source, String name) {
        if (org.stepan1411.pvp_bot.bot.BotPath.deletePath(name)) {
            source.method_9226(() -> class_2561.method_43470("§aPath '" + name + "' deleted"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cPath '" + name + "' not found"));
            return 0;
        }
    }
    
    private static int addPathPoint(class_2168 source, String name) {
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("§cOnly players can add path points"));
            return 0;
        }
        
        net.minecraft.class_243 pos = new net.minecraft.class_243(player.method_23317(), player.method_23318(), player.method_23321());
        if (org.stepan1411.pvp_bot.bot.BotPath.addPoint(name, pos)) {
            var path = org.stepan1411.pvp_bot.bot.BotPath.getPath(name);
            // Автоматически включаем визуализацию если ещё не включена
            if (!org.stepan1411.pvp_bot.bot.BotPath.isPathVisible(name)) {
                org.stepan1411.pvp_bot.bot.BotPath.setPathVisible(name, true);
                source.method_9226(() -> class_2561.method_43470("§7Visualization enabled. To disable: §e/pvpbot path show " + name + " false"), false);
            }
            source.method_9226(() -> class_2561.method_43470(String.format("§aPoint #%d added to path '%s' at (%.1f, %.1f, %.1f)", 
                path.points.size(), name, pos.field_1352, pos.field_1351, pos.field_1350)), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cPath '" + name + "' not found"));
            return 0;
        }
    }
    
    private static int removeLastPathPoint(class_2168 source, String name) {
        if (org.stepan1411.pvp_bot.bot.BotPath.removeLastPoint(name)) {
            source.method_9226(() -> class_2561.method_43470("§aLast point removed from path '" + name + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cPath '" + name + "' not found or empty"));
            return 0;
        }
    }
    
    private static int removePathPoint(class_2168 source, String name, int index) {
        if (org.stepan1411.pvp_bot.bot.BotPath.removePoint(name, index)) {
            source.method_9226(() -> class_2561.method_43470("§aPoint #" + index + " removed from path '" + name + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cInvalid path or index"));
            return 0;
        }
    }
    
    private static int clearPath(class_2168 source, String name) {
        if (org.stepan1411.pvp_bot.bot.BotPath.clearPath(name)) {
            source.method_9226(() -> class_2561.method_43470("§aAll points cleared from path '" + name + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cPath '" + name + "' not found"));
            return 0;
        }
    }
    
    private static int setPathLoop(class_2168 source, String name, boolean loop) {
        if (org.stepan1411.pvp_bot.bot.BotPath.setLoop(name, loop)) {
            source.method_9226(() -> class_2561.method_43470("§aPath '" + name + "' loop: " + loop), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cPath '" + name + "' not found"));
            return 0;
        }
    }
    
    private static int setPathAttack(class_2168 source, String name, boolean attack) {
        if (org.stepan1411.pvp_bot.bot.BotPath.setAttack(name, attack)) {
            if (attack) {
                source.method_9226(() -> class_2561.method_43470("§aPath '" + name + "' attack: enabled"), true);
            } else {
                source.method_9226(() -> class_2561.method_43470("§aPath '" + name + "' attack: disabled"), true);
                source.method_9226(() -> class_2561.method_43470("§7Bot will ignore attacks and continue following path"), false);
            }
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cPath '" + name + "' not found"));
            return 0;
        }
    }
    
    private static int startPathFollowing(class_2168 source, String botName, String pathName) {
        if (org.stepan1411.pvp_bot.bot.BotPath.startFollowing(botName, pathName)) {
            source.method_9226(() -> class_2561.method_43470("§aBot '" + botName + "' started following path '" + pathName + "'"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cPath '" + pathName + "' not found or empty"));
            return 0;
        }
    }
    
    private static int stopPathFollowing(class_2168 source, String botName) {
        if (org.stepan1411.pvp_bot.bot.BotPath.stopFollowing(botName)) {
            source.method_9226(() -> class_2561.method_43470("§aBot '" + botName + "' stopped following path"), true);
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cBot '" + botName + "' is not following any path"));
            return 0;
        }
    }
    
    private static int listPaths(class_2168 source) {
        var paths = org.stepan1411.pvp_bot.bot.BotPath.getAllPaths();
        if (paths.isEmpty()) {
            source.method_9226(() -> class_2561.method_43470("§eNo paths created"), false);
            return 0;
        }
        
        source.method_9226(() -> class_2561.method_43470("§6=== Paths ==="), false);
        for (var entry : paths.entrySet()) {
            String name = entry.getKey();
            var path = entry.getValue();
            source.method_9226(() -> class_2561.method_43470(String.format("§e%s§7: %d points, loop: %s, attack: %s", 
                name, path.points.size(), path.loop, path.attack)), false);
        }
        return paths.size();
    }
    
    private static int pathInfo(class_2168 source, String name) {
        var path = org.stepan1411.pvp_bot.bot.BotPath.getPath(name);
        if (path == null) {
            source.method_9213(class_2561.method_43470("§cPath '" + name + "' not found"));
            return 0;
        }
        
        source.method_9226(() -> class_2561.method_43470("§6=== Path: " + name + " ==="), false);
        source.method_9226(() -> class_2561.method_43470("§7Points: " + path.points.size()), false);
        source.method_9226(() -> class_2561.method_43470("§7Loop: " + path.loop), false);
        source.method_9226(() -> class_2561.method_43470("§7Attack: " + path.attack), false);
        
        for (int i = 0; i < path.points.size(); i++) {
            var point = path.points.get(i);
            int index = i;
            source.method_9226(() -> class_2561.method_43470(String.format("§e#%d§7: (%.1f, %.1f, %.1f)", 
                index, point.field_1352, point.field_1351, point.field_1350)), false);
        }
        
        return 1;
    }
    
    private static int showPath(class_2168 source, String name, boolean visible) {
        if (org.stepan1411.pvp_bot.bot.BotPath.setPathVisible(name, visible)) {
            if (visible) {
                source.method_9226(() -> class_2561.method_43470("§aPath '" + name + "' visualization enabled"), true);
                source.method_9226(() -> class_2561.method_43470("§7To disable: §e/pvpbot path show " + name + " false"), false);
            } else {
                source.method_9226(() -> class_2561.method_43470("§aPath '" + name + "' visualization disabled"), true);
            }
            return 1;
        } else {
            source.method_9213(class_2561.method_43470("§cPath '" + name + "' not found"));
            return 0;
        }
    }
    
    // ========== NEW PATH COMMANDS ==========
    
    private static int distributeBotsOnPath(class_2168 source, String pathName) {
        var path = BotPath.getPath(pathName);
        if (path == null) {
            source.method_9213(class_2561.method_43470("§cPath '" + pathName + "' not found"));
            return 0;
        }
        
        if (path.points.isEmpty()) {
            source.method_9213(class_2561.method_43470("§cPath '" + pathName + "' has no points"));
            return 0;
        }
        
        // Get all bots following this path
        var server = source.method_9211();
        var botsOnPath = new java.util.ArrayList<String>();
        for (String botName : BotManager.getAllBots()) {
            if (BotPath.isFollowing(botName, pathName)) {
                botsOnPath.add(botName);
            }
        }
        
        if (botsOnPath.isEmpty()) {
            source.method_9213(class_2561.method_43470("§cNo bots are following path '" + pathName + "'"));
            return 0;
        }
        
        // Distribute bots evenly along the path
        int totalPoints = path.points.size();
        int botCount = botsOnPath.size();
        
        for (int i = 0; i < botCount; i++) {
            String botName = botsOnPath.get(i);
            int pointIndex = (i * totalPoints) / botCount;
            
            // Set bot's current point on path
            BotPath.setBotPathIndex(botName, pointIndex);
            
            // Teleport bot to that point (1 block above to avoid getting stuck)
            var point = path.points.get(pointIndex);
            try {
                String tpCommand = String.format(java.util.Locale.US,
                    "tp %s %.2f %.2f %.2f",
                    botName, point.field_1352, point.field_1351 + 1.0, point.field_1350
                );
                server.method_3734().method_9235().execute(tpCommand, server.method_3739());
            } catch (Exception e) {
                // Ignore teleport errors
            }
        }
        
        source.method_9226(() -> class_2561.method_43470("§aDistributed " + botCount + " bots along path '" + pathName + "'"), true);
        return botCount;
    }
    
    private static int startPathNear(class_2168 source, String pathName, double radius) {
        var path = BotPath.getPath(pathName);
        if (path == null) {
            source.method_9213(class_2561.method_43470("§cPath '" + pathName + "' not found"));
            return 0;
        }
        
        class_3222 player = source.method_44023();
        if (player == null) {
            source.method_9213(class_2561.method_43470("§cThis command can only be used by a player"));
            return 0;
        }
        
        var server = source.method_9211();
        int started = 0;
        
        for (String botName : BotManager.getAllBots()) {
            class_3222 bot = server.method_3760().method_14566(botName);
            if (bot != null) {
                double distance = bot.method_5739(player);
                if (distance <= radius) {
                    if (BotPath.startFollowing(botName, pathName)) {
                        started++;
                    }
                }
            }
        }
        
        if (started > 0) {
            int finalStarted = started;
            source.method_9226(() -> class_2561.method_43470("§aStarted path '" + pathName + "' for " + finalStarted + " bots within " + radius + " blocks"), true);
            return started;
        } else {
            source.method_9213(class_2561.method_43470("§cNo bots found within " + radius + " blocks"));
            return 0;
        }
    }
    
    private static int stopAllOnPath(class_2168 source, String pathName) {
        var path = BotPath.getPath(pathName);
        if (path == null) {
            source.method_9213(class_2561.method_43470("§cPath '" + pathName + "' not found"));
            return 0;
        }
        
        int stopped = 0;
        for (String botName : BotManager.getAllBots()) {
            if (BotPath.isFollowing(botName, pathName)) {
                if (BotPath.stopFollowing(botName)) {
                    stopped++;
                }
            }
        }
        
        if (stopped > 0) {
            int finalStopped = stopped;
            source.method_9226(() -> class_2561.method_43470("§aStopped " + finalStopped + " bots on path '" + pathName + "'"), true);
            return stopped;
        } else {
            source.method_9213(class_2561.method_43470("§cNo bots are following path '" + pathName + "'"));
            return 0;
        }
    }
    
    // ========== FACTION PATH COMMANDS ==========
    
    private static int factionStartPath(class_2168 source, String factionName, String pathName) {
        var members = BotFaction.getMembers(factionName);
        if (members.isEmpty()) {
            source.method_9213(class_2561.method_43470("§cFaction '" + factionName + "' not found or has no members"));
            return 0;
        }
        
        var path = BotPath.getPath(pathName);
        if (path == null) {
            source.method_9213(class_2561.method_43470("§cPath '" + pathName + "' not found"));
            return 0;
        }
        
        int started = 0;
        for (String member : members) {
            if (BotManager.getAllBots().contains(member)) {
                if (BotPath.startFollowing(member, pathName)) {
                    started++;
                }
            }
        }
        
        if (started > 0) {
            int finalStarted = started;
            source.method_9226(() -> class_2561.method_43470("§aStarted path '" + pathName + "' for " + finalStarted + " bots in faction '" + factionName + "'"), true);
            return started;
        } else {
            source.method_9213(class_2561.method_43470("§cNo bots in faction '" + factionName + "'"));
            return 0;
        }
    }
    
    private static int factionStopPath(class_2168 source, String factionName) {
        var members = BotFaction.getMembers(factionName);
        if (members.isEmpty()) {
            source.method_9213(class_2561.method_43470("§cFaction '" + factionName + "' not found or has no members"));
            return 0;
        }
        
        int stopped = 0;
        for (String member : members) {
            if (BotManager.getAllBots().contains(member)) {
                if (BotPath.stopFollowing(member)) {
                    stopped++;
                }
            }
        }
        
        if (stopped > 0) {
            int finalStopped = stopped;
            source.method_9226(() -> class_2561.method_43470("§aStopped path for " + finalStopped + " bots in faction '" + factionName + "'"), true);
            return stopped;
        } else {
            source.method_9213(class_2561.method_43470("§cNo bots in faction '" + factionName + "' were following a path"));
            return 0;
        }
    }
}
