package org.stepan1411.pvp_bot.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_526;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Path;

public class PvpBotClient implements ClientModInitializer {
    
    private static final Logger LOGGER = LoggerFactory.getLogger("PVP_BOT_CLIENT");
    private static final String WARNING_FILE = "no_singleplayer_warning.txt";
    private static boolean warningShown = false;
    
    @Override
    public void onInitializeClient() {
        LOGGER.info("PVP Bot client initializing...");
        

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (warningShown) return;
            

            if (!(screen instanceof class_526)) return;
            
            LOGGER.info("SelectWorldScreen opened, checking warning...");
            

            Path configDir = FabricLoader.getInstance().getConfigDir().resolve("pvpbot");
            Path warningFile = configDir.resolve(WARNING_FILE);
            
            if (Files.exists(warningFile)) {
                LOGGER.info("Warning disabled by user");
                warningShown = true;
                return;
            }
            
            warningShown = true;
            LOGGER.info("Showing warning screen");
            

            client.method_1507(new WarningScreen(screen));
        });
        
        LOGGER.info("PVP Bot client initialized");
    }
}
