package org.stepan1411.pvp_bot.gui;

import eu.pb4.sgui.api.elements.GuiElementBuilder;
import eu.pb4.sgui.api.gui.SimpleGui;
import net.minecraft.class_124;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3917;
import net.minecraft.server.MinecraftServer;
import org.stepan1411.pvp_bot.bot.BotFaction;
import org.stepan1411.pvp_bot.bot.BotKits;
import org.stepan1411.pvp_bot.bot.BotManager;


public class BotMenuGui {
    
    
    public static void openMainMenu(class_3222 player) {
        SimpleGui gui = new SimpleGui(class_3917.field_17328, player, false);
        gui.setTitle(class_2561.method_43470("PVP Bot Menu"));
        
        MinecraftServer server = player.method_64396().method_9211();
        

        gui.setSlot(0, new GuiElementBuilder()
            .setItem(class_1802.field_8674)
            .setName(class_2561.method_43470("Settings").method_27692(class_124.field_1060))
            .addLoreLine(class_2561.method_43470("Global bot settings").method_27692(class_124.field_1080))
            .setCallback((index, type, action) -> {
                gui.close();
                SettingsGui settingsGui = new SettingsGui(player);
                settingsGui.open();
            })
        );
        

        gui.setSlot(1, new GuiElementBuilder()
            .setItem(class_1802.field_8575)
            .setName(class_2561.method_43470("Bot List").method_27692(class_124.field_1075))
            .addLoreLine(class_2561.method_43470("Manage bots").method_27692(class_124.field_1080))
            .addLoreLine(class_2561.method_43470("Bots: " + BotManager.getBotCount()).method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                gui.close();
                openBotListMenu(player, server);
            })
        );
        

        gui.setSlot(2, new GuiElementBuilder()
            .setItem(class_1802.field_8539)
            .setName(class_2561.method_43470("Factions").method_27692(class_124.field_1076))
            .addLoreLine(class_2561.method_43470("Manage factions").method_27692(class_124.field_1080))
            .addLoreLine(class_2561.method_43470("Factions: " + BotFaction.getAllFactions().size()).method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                gui.close();
                openFactionsMenu(player, server);
            })
        );
        

        gui.setSlot(3, new GuiElementBuilder()
            .setItem(class_1802.field_8106)
            .setName(class_2561.method_43470("Kits").method_27692(class_124.field_1065))
            .addLoreLine(class_2561.method_43470("Manage kits").method_27692(class_124.field_1080))
            .addLoreLine(class_2561.method_43470("Kits: " + BotKits.getKitNames().size()).method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                player.method_7353(class_2561.method_43470("Kits: " + String.join(", ", BotKits.getKitNames())), false);
            })
        );
        

        gui.setSlot(8, new GuiElementBuilder()
            .setItem(class_1802.field_8077)
            .setName(class_2561.method_43470("Close").method_27692(class_124.field_1061))
            .setCallback((index, type, action) -> gui.close())
        );
        
        gui.open();
    }
    
    public static void openBotListMenu(class_3222 player, MinecraftServer server) {
        var bots = BotManager.getAllBots();
        
        if (bots.isEmpty()) {
            player.method_7353(class_2561.method_43470("No bots spawned!").method_27692(class_124.field_1061), false);
            openMainMenu(player);
            return;
        }
        
        SimpleGui gui = new SimpleGui(class_3917.field_17327, player, false);
        gui.setTitle(class_2561.method_43470("Bot List (" + bots.size() + ")"));
        
        int slot = 0;
        for (String botName : bots) {
            if (slot >= 45) break;
            
            String faction = BotFaction.getFaction(botName);
            
            gui.setSlot(slot++, new GuiElementBuilder()
                .setItem(class_1802.field_8575)
                .setName(class_2561.method_43470(botName).method_27692(class_124.field_1054))
                .addLoreLine(class_2561.method_43470("Faction: " + (faction != null ? faction : "None")).method_27692(class_124.field_1080))
                .addLoreLine(class_2561.method_43470(""))
                .addLoreLine(class_2561.method_43470("Click to manage").method_27692(class_124.field_1060))
                .setCallback((index, type, action) -> {
                    gui.close();
                    openBotManageMenu(player, server, botName);
                })
            );
        }
        
        gui.setSlot(45, new GuiElementBuilder()
            .setItem(class_1802.field_8107)
            .setName(class_2561.method_43470("Back").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                gui.close();
                openMainMenu(player);
            })
        );
        
        gui.open();
    }
    
    public static void openBotManageMenu(class_3222 player, MinecraftServer server, String botName) {
        var bot = BotManager.getBot(server, botName);
        if (bot == null) {
            player.method_7353(class_2561.method_43470("Bot not found!").method_27692(class_124.field_1061), false);
            openBotListMenu(player, server);
            return;
        }
        
        SimpleGui gui = new SimpleGui(class_3917.field_17326, player, false);
        gui.setTitle(class_2561.method_43470("Manage: " + botName));
        
        String faction = BotFaction.getFaction(botName);
        
        gui.setSlot(0, new GuiElementBuilder()
            .setItem(class_1802.field_8539)
            .setName(class_2561.method_43470("Faction").method_27692(class_124.field_1076))
            .addLoreLine(class_2561.method_43470("Current: " + (faction != null ? faction : "None")).method_27692(class_124.field_1080))
            .addLoreLine(class_2561.method_43470(""))
            .addLoreLine(class_2561.method_43470("Click to change").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                gui.close();
                openBotFactionSelectMenu(player, server, botName);
            })
        );
        
        gui.setSlot(1, new GuiElementBuilder()
            .setItem(class_1802.field_8463)
            .setName(class_2561.method_43470("Heal").method_27692(class_124.field_1060))
            .addLoreLine(class_2561.method_43470("HP: " + String.format("%.1f", bot.method_6032()) + "/" + String.format("%.1f", bot.method_6063())).method_27692(class_124.field_1080))
            .addLoreLine(class_2561.method_43470(""))
            .addLoreLine(class_2561.method_43470("Click to heal").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                bot.method_6033(bot.method_6063());
                player.method_7353(class_2561.method_43470("Healed " + botName + " to full HP!").method_27692(class_124.field_1060), false);
                gui.close();
                openBotManageMenu(player, server, botName);
            })
        );
        
        gui.setSlot(2, new GuiElementBuilder()
            .setItem(class_1802.field_8106)
            .setName(class_2561.method_43470("Inventory").method_27692(class_124.field_1065))
            .addLoreLine(class_2561.method_43470("View bot inventory").method_27692(class_124.field_1080))
            .setCallback((index, type, action) -> {
                gui.close();
                try {
                    openInvViewGui(player, bot);
                } catch (Exception e) {
                    player.method_7353(class_2561.method_43470("InvView not available!").method_27692(class_124.field_1061), false);
                    openBotManageMenu(player, server, botName);
                }
            })
        );
        
        gui.setSlot(3, new GuiElementBuilder()
            .setItem(class_1802.field_8634)
            .setName(class_2561.method_43470("Teleport").method_27692(class_124.field_1075))
            .addLoreLine(class_2561.method_43470("Teleport to bot").method_27692(class_124.field_1080))
            .setCallback((index, type, action) -> {
                player.method_5859(bot.method_23317(), bot.method_23318(), bot.method_23321());
                player.method_36456(bot.method_36454());
                player.method_36457(bot.method_36455());
                player.method_7353(class_2561.method_43470("Teleported to " + botName).method_27692(class_124.field_1060), false);
                gui.close();
            })
        );
        
        gui.setSlot(4, new GuiElementBuilder()
            .setItem(class_1802.field_8077)
            .setName(class_2561.method_43470("Remove Bot").method_27692(class_124.field_1061))
            .addLoreLine(class_2561.method_43470("Delete this bot").method_27692(class_124.field_1080))
            .setCallback((index, type, action) -> {
                BotManager.removeBot(server, botName, player.method_64396());
                player.method_7353(class_2561.method_43470("Removed bot " + botName).method_27692(class_124.field_1060), false);
                gui.close();
                openBotListMenu(player, server);
            })
        );
        
        gui.setSlot(18, new GuiElementBuilder()
            .setItem(class_1802.field_8107)
            .setName(class_2561.method_43470("Back").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                gui.close();
                openBotListMenu(player, server);
            })
        );
        
        gui.open();
    }
    
    public static void openBotFactionSelectMenu(class_3222 player, MinecraftServer server, String botName) {
        var factions = BotFaction.getAllFactions();
        
        SimpleGui gui = new SimpleGui(class_3917.field_17326, player, false);
        gui.setTitle(class_2561.method_43470("Select Faction for " + botName));
        
        int slot = 0;
        
        gui.setSlot(slot++, new GuiElementBuilder()
            .setItem(class_1802.field_8617)
            .setName(class_2561.method_43470("No Faction").method_27692(class_124.field_1080))
            .addLoreLine(class_2561.method_43470("Remove from faction").method_27692(class_124.field_1080))
            .setCallback((index, type, action) -> {
                String currentFaction = BotFaction.getFaction(botName);
                if (currentFaction != null) {
                    BotFaction.removeMember(currentFaction, botName);
                    player.method_7353(class_2561.method_43470("Removed " + botName + " from faction").method_27692(class_124.field_1060), false);
                }
                gui.close();
                openBotManageMenu(player, server, botName);
            })
        );
        
        for (String factionName : factions) {
            if (slot >= 18) break;
            
            var members = BotFaction.getMembers(factionName);
            boolean isMember = members != null && members.contains(botName);
            
            gui.setSlot(slot++, new GuiElementBuilder()
                .setItem(isMember ? class_1802.field_8778 : class_1802.field_8539)
                .setName(class_2561.method_43470(factionName).method_27692(isMember ? class_124.field_1060 : class_124.field_1068))
                .addLoreLine(class_2561.method_43470("Members: " + (members != null ? members.size() : 0)).method_27692(class_124.field_1080))
                .addLoreLine(class_2561.method_43470(""))
                .addLoreLine(class_2561.method_43470(isMember ? "Current faction" : "Click to join").method_27692(isMember ? class_124.field_1060 : class_124.field_1054))
                .setCallback((index, type, action) -> {
                    String currentFaction = BotFaction.getFaction(botName);
                    if (currentFaction != null) {
                        BotFaction.removeMember(currentFaction, botName);
                    }
                    BotFaction.addMember(factionName, botName);
                    player.method_7353(class_2561.method_43470("Added " + botName + " to faction " + factionName).method_27692(class_124.field_1060), false);
                    gui.close();
                    openBotManageMenu(player, server, botName);
                })
            );
        }
        
        gui.setSlot(18, new GuiElementBuilder()
            .setItem(class_1802.field_8107)
            .setName(class_2561.method_43470("Back").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                gui.close();
                openBotManageMenu(player, server, botName);
            })
        );
        
        gui.open();
    }
    
    public static void openFactionsMenu(class_3222 player, MinecraftServer server) {
        var factions = BotFaction.getAllFactions();
        
        SimpleGui gui = new SimpleGui(class_3917.field_17327, player, false);
        gui.setTitle(class_2561.method_43470("Factions (" + factions.size() + ")"));
        
        int slot = 0;
        for (String factionName : factions) {
            if (slot >= 45) break;
            
            var members = BotFaction.getMembers(factionName);
            var enemies = BotFaction.getHostileFactions(factionName);
            
            gui.setSlot(slot++, new GuiElementBuilder()
                .setItem(class_1802.field_8539)
                .setName(class_2561.method_43470(factionName).method_27692(class_124.field_1076))
                .addLoreLine(class_2561.method_43470("Members: " + (members != null ? members.size() : 0)).method_27692(class_124.field_1080))
                .addLoreLine(class_2561.method_43470("Enemies: " + (enemies != null ? enemies.size() : 0)).method_27692(class_124.field_1061))
                .addLoreLine(class_2561.method_43470(""))
                .addLoreLine(class_2561.method_43470("Click to manage").method_27692(class_124.field_1054))
                .setCallback((index, type, action) -> {
                    gui.close();
                    openFactionManageMenu(player, server, factionName);
                })
            );
        }
        
        gui.setSlot(45, new GuiElementBuilder()
            .setItem(class_1802.field_8674)
            .setName(class_2561.method_43470("Create Faction").method_27692(class_124.field_1060))
            .addLoreLine(class_2561.method_43470("Use /pvpbot faction create <name>").method_27692(class_124.field_1080))
            .setCallback((index, type, action) -> {
                player.method_7353(class_2561.method_43470("Use: /pvpbot faction create <name>").method_27692(class_124.field_1054), false);
            })
        );
        
        gui.setSlot(53, new GuiElementBuilder()
            .setItem(class_1802.field_8107)
            .setName(class_2561.method_43470("Back").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                gui.close();
                openMainMenu(player);
            })
        );
        
        gui.open();
    }
    
    public static void openFactionManageMenu(class_3222 player, MinecraftServer server, String factionName) {
        if (!BotFaction.getAllFactions().contains(factionName)) {
            player.method_7353(class_2561.method_43470("Faction not found!").method_27692(class_124.field_1061), false);
            openFactionsMenu(player, server);
            return;
        }
        
        SimpleGui gui = new SimpleGui(class_3917.field_17326, player, false);
        gui.setTitle(class_2561.method_43470("Faction: " + factionName));
        
        var members = BotFaction.getMembers(factionName);
        var enemies = BotFaction.getHostileFactions(factionName);
        
        gui.setSlot(0, new GuiElementBuilder()
            .setItem(class_1802.field_8575)
            .setName(class_2561.method_43470("Members").method_27692(class_124.field_1075))
            .addLoreLine(class_2561.method_43470("Count: " + (members != null ? members.size() : 0)).method_27692(class_124.field_1080))
            .addLoreLine(class_2561.method_43470(""))
            .addLoreLine(class_2561.method_43470("Click to view").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                if (members != null && !members.isEmpty()) {
                    player.method_7353(class_2561.method_43470("Members: " + String.join(", ", members)).method_27692(class_124.field_1075), false);
                } else {
                    player.method_7353(class_2561.method_43470("No members").method_27692(class_124.field_1080), false);
                }
            })
        );
        
        gui.setSlot(1, new GuiElementBuilder()
            .setItem(class_1802.field_8371)
            .setName(class_2561.method_43470("Enemies").method_27692(class_124.field_1061))
            .addLoreLine(class_2561.method_43470("Count: " + (enemies != null ? enemies.size() : 0)).method_27692(class_124.field_1080))
            .addLoreLine(class_2561.method_43470(""))
            .addLoreLine(class_2561.method_43470("Click to view").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                if (enemies != null && !enemies.isEmpty()) {
                    player.method_7353(class_2561.method_43470("Enemies: " + String.join(", ", enemies)).method_27692(class_124.field_1061), false);
                } else {
                    player.method_7353(class_2561.method_43470("No enemies").method_27692(class_124.field_1080), false);
                }
            })
        );
        
        gui.setSlot(2, new GuiElementBuilder()
            .setItem(class_1802.field_8463)
            .setName(class_2561.method_43470("Heal All").method_27692(class_124.field_1060))
            .addLoreLine(class_2561.method_43470("Heal all faction members").method_27692(class_124.field_1080))
            .setCallback((index, type, action) -> {
                if (members != null) {
                    int healed = 0;
                    for (String memberName : members) {
                        if (BotManager.getAllBots().contains(memberName)) {
                            var bot = BotManager.getBot(server, memberName);
                            if (bot != null) {
                                bot.method_6033(bot.method_6063());
                                healed++;
                            }
                        }
                    }
                    player.method_7353(class_2561.method_43470("Healed " + healed + " bots in faction " + factionName).method_27692(class_124.field_1060), false);
                }
            })
        );
        
        gui.setSlot(3, new GuiElementBuilder()
            .setItem(class_1802.field_8077)
            .setName(class_2561.method_43470("Delete Faction").method_27692(class_124.field_1061))
            .addLoreLine(class_2561.method_43470("Permanently delete").method_27692(class_124.field_1080))
            .setCallback((index, type, action) -> {
                BotFaction.deleteFaction(factionName);
                player.method_7353(class_2561.method_43470("Deleted faction " + factionName).method_27692(class_124.field_1060), false);
                gui.close();
                openFactionsMenu(player, server);
            })
        );
        
        gui.setSlot(18, new GuiElementBuilder()
            .setItem(class_1802.field_8107)
            .setName(class_2561.method_43470("Back").method_27692(class_124.field_1054))
            .setCallback((index, type, action) -> {
                gui.close();
                openFactionsMenu(player, server);
            })
        );
        
        gui.open();
    }
    
    private static void openInvViewGui(class_3222 viewer, class_3222 target) throws Exception {
        Class<?> guiClass = Class.forName("us.potatoboy.invview.gui.SavingPlayerDataGui");
        var constructor = guiClass.getConstructor(class_3222.class, class_3222.class);
        var gui = constructor.newInstance(viewer, target);
        var openMethod = guiClass.getMethod("open");
        openMethod.invoke(gui);
    }
}
