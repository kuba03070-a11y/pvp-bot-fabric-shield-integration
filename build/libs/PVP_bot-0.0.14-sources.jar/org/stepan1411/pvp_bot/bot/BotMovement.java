package org.stepan1411.pvp_bot.bot;

import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;


public class BotMovement {
    

    public enum MovementType {
        NONE,
        FOLLOW,
        ESCORT,
        GOTO
    }
    

    public static class MovementState {
        public MovementType type = MovementType.NONE;
        public String targetName = null;
        public class_243 targetPos = null;
        public boolean isEscort = false;
        public long lastUpdate = 0;
        
        public void reset() {
            type = MovementType.NONE;
            targetName = null;
            targetPos = null;
            isEscort = false;
            lastUpdate = 0;
        }
    }
    

    private static final Map<String, MovementState> botStates = new ConcurrentHashMap<>();
    

    private static final double FOLLOW_DISTANCE = 3.0;
    private static final double GOTO_THRESHOLD = 2.0;
    
    
    public static void setFollow(String botName, String targetName, boolean escort) {
        MovementState state = getOrCreateState(botName);
        state.type = escort ? MovementType.ESCORT : MovementType.FOLLOW;
        state.targetName = targetName;
        state.isEscort = escort;
        state.targetPos = null;
        state.lastUpdate = System.currentTimeMillis();
        
        System.out.println("[BotMovement] " + botName + " set to " + 
            (escort ? "escort" : "follow") + " " + targetName);
    }
    
    
    public static void setGoto(String botName, class_243 position) {
        MovementState state = getOrCreateState(botName);
        state.type = MovementType.GOTO;
        state.targetPos = position;
        state.targetName = null;
        state.isEscort = false;
        state.lastUpdate = System.currentTimeMillis();
        
        System.out.println("[BotMovement] " + botName + " set to goto " + 
            String.format("%.1f %.1f %.1f", position.field_1352, position.field_1351, position.field_1350));
    }
    
    
    public static void stop(String botName) {
        MovementState state = botStates.get(botName);
        if (state != null) {
            System.out.println("[BotMovement] " + botName + " movement stopped");
            

            try {

                for (String existingBotName : BotManager.getAllBots()) {
                    if (existingBotName.equals(botName)) {
                        class_3222 bot = BotManager.getBot(null, botName);
                        if (bot != null) {

                            if (BotBaritone.isBaritoneAvailable(bot)) {
                                BotBaritone.stop(bot);
                            }

                            HerobotMovement.stopMovement(bot);
                        }
                        break;
                    }
                }
            } catch (Exception e) {

            }
            
            state.reset();
        }
    }
    
    
    public static void updateMovement(class_3222 bot) {
        String botName = bot.method_5477().getString();
        MovementState state = botStates.get(botName);
        
        if (state == null || state.type == MovementType.NONE) {
            return;
        }
        
        long currentTime = System.currentTimeMillis();
        if (currentTime - state.lastUpdate < 50) {
            return;
        }
        state.lastUpdate = currentTime;
        
        switch (state.type) {
            case FOLLOW:
            case ESCORT:
                updateFollow(bot, state);
                break;
            case GOTO:
                updateGoto(bot, state);
                break;
        }
    }
    
    
    private static void updateFollow(class_3222 bot, MovementState state) {
        if (state.targetName == null) {
            return;
        }
        

        class_1297 target = findTarget(bot, state.targetName);
        if (target == null) {
            System.out.println("[BotMovement] " + bot.method_5477().getString() + " lost target " + state.targetName);

            if (BotBaritone.isBaritoneAvailable(bot)) {
                BotBaritone.stop(bot);
            }
            HerobotMovement.stopMovement(bot);
            return;
        }
        
        double distance = bot.method_5739(target);
        

        if (distance > FOLLOW_DISTANCE) {
            class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
            

            if (state.isEscort && BotSettings.get().isEscortUseBaritone()) {

                moveWithPathfindingToEntity(bot, target);
            } else if (!state.isEscort && BotSettings.get().isFollowUseBaritone()) {

                moveWithPathfindingToEntity(bot, target);
            } else {

                moveTowardsTarget(bot, targetPos);
            }
        } else {

            if (BotBaritone.isBaritoneAvailable(bot)) {
                BotBaritone.stop(bot);
            }
            HerobotMovement.stopMovement(bot);
        }
        

        if (state.isEscort) {
            checkEscortDefense(bot, target);
        }
    }
    
    
    private static void updateGoto(class_3222 bot, MovementState state) {
        if (state.targetPos == null) {
            return;
        }
        
        double distance = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321()).method_1022(state.targetPos);
        

        if (distance <= GOTO_THRESHOLD) {
            System.out.println("[BotMovement] " + bot.method_5477().getString() + " reached destination");
            if (BotBaritone.isBaritoneAvailable(bot)) {
                BotBaritone.stop(bot);
            }
            HerobotMovement.stopMovement(bot);
            stop(bot.method_5477().getString());
            return;
        }
        

        if (BotSettings.get().isGotoUseBaritone()) {

            moveWithPathfinding(bot, state.targetPos);
        } else {

            moveTowardsTarget(bot, state.targetPos);
        }
    }
    
    
    private static void moveTowardsTarget(class_3222 bot, class_243 targetPos) {

        HerobotMovement.walkTowards(bot, targetPos);
    }
    
    
    private static void moveWithPathfinding(class_3222 bot, class_243 targetPos) {
        moveWithPathfindingToPosition(bot, targetPos, null);
    }
    
    
    private static void moveWithPathfindingToEntity(class_3222 bot, class_1297 target) {
        moveWithPathfindingToPosition(bot, null, target);
    }
    
    
    private static void moveWithPathfindingToPosition(class_3222 bot, class_243 targetPos, class_1297 targetEntity) {

        if (!BotBaritone.isBaritoneAvailable(bot)) {

            if (targetPos != null) {
                moveTowardsTarget(bot, targetPos);
            } else if (targetEntity != null) {
                moveTowardsTarget(bot, new class_243(targetEntity.method_23317(), targetEntity.method_23318(), targetEntity.method_23321()));
            }
            return;
        }
        

        class_243 actualTargetPos = targetPos;
        if (targetEntity != null) {
            actualTargetPos = new class_243(targetEntity.method_23317(), targetEntity.method_23318(), targetEntity.method_23321());
        }
        
        if (actualTargetPos == null) {
            return;
        }
        

        class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
        double distance = botPos.method_1022(actualTargetPos);
        String botName = bot.method_5477().getString();
        

        if (distance <= 2.0) {
            BotBaritone.stop(bot);
            moveTowardsTarget(bot, actualTargetPos);
            return;
        }
        

        BotBaritone.stop(bot);
        if (targetEntity != null) {
            BotBaritone.goToEntity(bot, targetEntity, FOLLOW_DISTANCE);
        } else {
            BotBaritone.goToPosition(bot, actualTargetPos);
        }
        

        if (distance > 4.0) {
            HerobotMovement.sprint(bot, true);
        } else {
            HerobotMovement.sprint(bot, false);
        }
        

        if (BotSettings.get().isBhopEnabled() && distance > 3.0 && bot.method_24828()) {

            long currentTime = System.currentTimeMillis();
            Long lastBhop = bhopCooldowns.get(botName);
            
            if (lastBhop == null || currentTime - lastBhop > (BotSettings.get().getBhopCooldown() * 50)) {
                HerobotMovement.jump(bot);
                bhopCooldowns.put(botName, currentTime);
            }
        }
    }
    

    private static final Map<String, Long> bhopCooldowns = new ConcurrentHashMap<>();
    
    
    private static boolean shouldJump(class_3222 bot, class_243 targetPos) {

        return targetPos.field_1351 > bot.method_23318() + 0.5;
    }
    
    
    private static class_1297 findTarget(class_3222 bot, String targetName) {
        try {

            var server = bot.method_64396().method_9211();
            if (server == null) return null;
            

            for (class_3222 player : server.method_3760().method_14571()) {
                if (player.method_5477().getString().equals(targetName)) {
                    return player;
                }
            }
            

            for (String botName : BotManager.getAllBots()) {
                if (botName.equals(targetName)) {
                    class_3222 targetBot = BotManager.getBot(server, botName);
                    if (targetBot != null) {
                        return targetBot;
                    }
                }
            }
        } catch (Exception e) {

        }
        
        return null;
    }
    
    
    private static void checkEscortDefense(class_3222 bot, class_1297 target) {


    }
    
    
    private static MovementState getOrCreateState(String botName) {
        return botStates.computeIfAbsent(botName, k -> new MovementState());
    }
    
    
    public static MovementState getState(String botName) {
        return botStates.get(botName);
    }
    
    
    public static void clearState(String botName) {

        try {
            BotBaritone.removeBaritone(botName);
        } catch (Exception e) {

        }
        

        botStates.remove(botName);
        

        bhopCooldowns.remove(botName);
    }
}