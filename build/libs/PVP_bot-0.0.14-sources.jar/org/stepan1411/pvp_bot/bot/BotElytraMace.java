package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import org.stepan1411.pvp_bot.bot.BotSettings;


public class BotElytraMace {
    
    
    private static class ElytraMaceState {
        int step = 0;
        int cooldownTicks = 0;
        int stuckCounter = 0;
        int lastStep = -1;
        

        boolean elytraEquipped = false;
        int takeoffTicks = 0;
        double startY = 0;
        int waitTicks = 0;
        int retryCount = 0;
        

        int elytraSlot = -1;
        int chestplateSlot = -1;
        int fireworkSlot = -1;
        int maceSlot = -1;
    }
    
    private static final java.util.Map<String, ElytraMaceState> states = new java.util.HashMap<>();
    
    
    private static ElytraMaceState getState(String botName) {
        return states.computeIfAbsent(botName, k -> new ElytraMaceState());
    }
    
    
    public static boolean canUseElytraMace(class_3222 bot, class_1297 target, BotSettings settings) {
        if (!settings.isElytraMaceEnabled()) {
            return false;
        }
        
        double distance = bot.method_5739(target);
        if (distance > 15.0) {
            return false;
        }
        
        class_1661 inventory = bot.method_31548();
        boolean hasAllItems = hasElytra(inventory) && hasMace(inventory) && hasFireworks(inventory) && hasChestplate(inventory);
        
        return hasAllItems;
    }
    
    
    public static boolean doElytraMace(class_3222 bot, class_1297 target, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        ElytraMaceState state = getState(bot.method_5477().getString());
        class_1937 world = bot.method_51469();
        double distance = bot.method_5739(target);
        

        if (state.step == state.lastStep) {
            state.stuckCounter++;
            if (state.stuckCounter > 100) {
                resetState(state);
                return true;
            }
        } else {
            state.stuckCounter = 0;
            state.lastStep = state.step;
        }
        

        if (state.cooldownTicks > 0) {
            state.cooldownTicks--;
            return true;
        }
        
        if (state.waitTicks > 0) {
            state.waitTicks--;
            return true;
        }
        

        if (distance > 20.0) {
            resetState(state);
            return true;
        }
        

        switch (state.step) {
            case 0:
                return stepPrepareElytra(bot, target, state, server, world, settings);
            case 1:
                return stepTakeoff(bot, target, state, server, world, settings);
            case 2:
                return stepWaitAltitude(bot, target, state, server, world, settings);
            case 3:
                return stepRemoveElytraAndWait(bot, target, state, server, world, settings);
            case 4:
                return stepGlideToTarget(bot, target, state, server, world, settings);
            case 5:
                return stepMaceAttack(bot, target, state, server, world, settings);
            default:
                resetState(state);
                return true;
        }
    }
    
    
    private static boolean stepPrepareElytra(class_3222 bot, class_1297 target, ElytraMaceState state, 
                                           net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        

        state.elytraSlot = findElytra(inventory);
        state.chestplateSlot = findChestplate(inventory);
        state.fireworkSlot = findFireworks(inventory);
        state.maceSlot = findMace(inventory);
        
        if (state.elytraSlot < 0 || state.fireworkSlot < 0 || state.maceSlot < 0) {
            return false;
        }
        

        if (!selectItem(bot, state.elytraSlot)) {
            return true;
        }
        

        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " use once", 
                server.method_3739()
            );
            
            state.elytraEquipped = true;
            state.step = 1;
            state.cooldownTicks = 5;
            
        } catch (Exception e) {

        }
        
        return true;
    }
    
    
    private static boolean stepTakeoff(class_3222 bot, class_1297 target, ElytraMaceState state,
                                     net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        

        if (state.takeoffTicks == 0) {
            state.startY = bot.method_23318();
        }
        
        state.takeoffTicks++;
        

        if (state.takeoffTicks == 1) {
            bot.method_36457(0.0f);
            bot.method_6043();
        }
        

        if (state.takeoffTicks == 5) {
            bot.method_6043();
        }
        

        if (state.takeoffTicks == 8) {
            if (!selectItem(bot, state.fireworkSlot)) {
                return true;
            }
            

            int fireworkCount = settings.getElytraMaceFireworkCount();
            try {
                for (int i = 0; i < fireworkCount; i++) {
                    server.method_3734().method_9235().execute(
                        "player " + bot.method_5477().getString() + " use once", 
                        server.method_3739()
                    );
                }
            } catch (Exception e) {

            }
        }
        

        if (state.takeoffTicks == 12) {
            bot.method_36457(-90.0f);
            state.step = 2;
            state.cooldownTicks = 3;
        }
        
        return true;
    }
    
    
    private static boolean stepWaitAltitude(class_3222 bot, class_1297 target, ElytraMaceState state,
                                          net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        state.takeoffTicks++;
        double currentHeight = bot.method_23318() - state.startY;
        int minAltitude = settings.getElytraMaceMinAltitude();
        

        if (currentHeight >= minAltitude) {
            state.step = 3;
            state.cooldownTicks = 0;
            return true;
        }
        

        if (state.takeoffTicks >= 80 || (state.takeoffTicks > 20 && currentHeight < 2.0)) {
            state.retryCount++;
            int maxRetries = settings.getElytraMaceMaxRetries();
            
            if (state.retryCount < maxRetries) {
                state.step = 0;
                state.takeoffTicks = 0;
                state.elytraEquipped = false;
                state.cooldownTicks = 10;
            } else {
                resetState(state);
                return false;
            }
        }
        
        return true;
    }
    
    
    private static boolean stepRemoveElytraAndWait(class_3222 bot, class_1297 target, ElytraMaceState state,
                                                 net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        

        if (state.chestplateSlot >= 0) {
            if (state.chestplateSlot != 38) {
                if (!selectItem(bot, state.chestplateSlot)) {
                    return true;
                }
            }
            

            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " use once", 
                    server.method_3739()
                );
            } catch (Exception e) {

            }
        }
        
        state.elytraEquipped = false;
        state.waitTicks = 5;
        state.step = 4;
        
        return true;
    }
    
    
    private static boolean stepGlideToTarget(class_3222 bot, class_1297 target, ElytraMaceState state,
                                           net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        double distance = bot.method_5739(target);
        

        if (!state.elytraEquipped) {
            if (!selectItem(bot, state.elytraSlot)) {
                return true;
            }
            
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " use once", 
                    server.method_3739()
                );
                state.elytraEquipped = true;
            } catch (Exception e) {

            }
            return true;
        }
        

        lookAtEntity(bot, target);
        

        double deltaX = target.method_23317() - bot.method_23317();
        double deltaY = target.method_23318() - bot.method_23318();
        double deltaZ = target.method_23321() - bot.method_23321();
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        

        float targetPitch = (float) Math.toDegrees(Math.atan2(deltaY, horizontalDistance));
        targetPitch = Math.max(30.0f, Math.min(90.0f, targetPitch));
        bot.method_36457(targetPitch);
        

        double attackDistance = settings.getElytraMaceAttackDistance();
        if (distance <= attackDistance) {
            state.step = 5;
            state.cooldownTicks = 0;
        }
        
        return true;
    }
    
    
    private static boolean stepMaceAttack(class_3222 bot, class_1297 target, ElytraMaceState state,
                                        net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        

        if (state.elytraEquipped && state.chestplateSlot >= 0) {
            if (state.chestplateSlot != 38) {
                if (!selectItem(bot, state.chestplateSlot)) {
                    return true;
                }
            }
            
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " use once", 
                    server.method_3739()
                );
                state.elytraEquipped = false;
            } catch (Exception e) {

            }
            return true;
        }
        

        if (!selectItem(bot, state.maceSlot)) {
            return true;
        }
        

        lookAtEntity(bot, target);
        

        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " attack once", 
                server.method_3739()
            );
        } catch (Exception e) {
            bot.method_6104(class_1268.field_5808);
        }
        

        resetState(state);
        state.cooldownTicks = 20;
        
        return true;
    }
    
    
    private static void resetState(ElytraMaceState state) {
        state.step = 0;
        state.elytraEquipped = false;
        state.takeoffTicks = 0;
        state.startY = 0;
        state.waitTicks = 0;
        state.stuckCounter = 0;
        state.lastStep = -1;
        state.retryCount = 0;
        state.elytraSlot = -1;
        state.chestplateSlot = -1;
        state.fireworkSlot = -1;
        state.maceSlot = -1;
    }
    
    
    private static void lookAtEntity(class_3222 bot, class_1297 target) {
        double dx = target.method_23317() - bot.method_23317();
        double dy = target.method_23318() - bot.method_23318();
        double dz = target.method_23321() - bot.method_23321();
        
        double distance = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) (Math.atan2(dy, distance) * 180.0 / Math.PI);
        
        bot.method_36456(yaw);
        bot.method_36457(-pitch);
    }
    
    
    private static boolean selectItem(class_3222 bot, int slot) {
        if (slot < 0 || slot >= 36) return false;
        
        class_1661 inventory = bot.method_31548();
        

        if (slot >= 9) {
            class_1799 item = inventory.method_5438(slot);
            class_1799 current = inventory.method_5438(8);
            inventory.method_5447(slot, current);
            inventory.method_5447(8, item);
            slot = 8;
        }
        
        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, slot);
        return true;
    }
    
    
    private static int findElytra(class_1661 inventory) {

        class_1799 equippedChest = inventory.method_5438(38);
        if (!equippedChest.method_7960() && equippedChest.method_7909() == class_1802.field_8833) {
            return 38;
        }
        

        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8833) {
                return i;
            }
        }
        return -1;
    }
    
    
    
    private static int findChestplate(class_1661 inventory) {

        class_1799 equippedChest = inventory.method_5438(38);
        if (!equippedChest.method_7960()) {
            String itemName = equippedChest.method_7909().toString().toLowerCase();
            if (itemName.contains("chestplate")) {
                return 38;
            }
        }
        

        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            String itemName = stack.method_7909().toString().toLowerCase();
            if (itemName.contains("chestplate")) {
                return i;
            }
        }
        return -1;
    }
    
    
    private static int findFireworks(class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8639) {
                return i;
            }
        }
        return -1;
    }
    
    
    private static int findMace(class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_49814) {
                return i;
            }
        }
        return -1;
    }
    
    
    private static boolean hasElytra(class_1661 inventory) {
        return findElytra(inventory) >= 0;
    }
    
    
    private static boolean hasMace(class_1661 inventory) {
        return findMace(inventory) >= 0;
    }
    
    
    private static boolean hasFireworks(class_1661 inventory) {
        return findFireworks(inventory) >= 0;
    }
    
    
    private static boolean hasChestplate(class_1661 inventory) {
        return findChestplate(inventory) >= 0;
    }
    
    
    public static void reset(String botName) {
        ElytraMaceState state = states.get(botName);
        if (state != null) {
            resetState(state);
        }
    }
}