package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import org.stepan1411.pvp_bot.bot.BotSettings;

/**
 * ElytraMace трюк - использование элитр и булавы для атаки сверху
 */
public class BotElytraMace {
    
    /**
     * Состояние ElytraMace трюка
     */
    private static class ElytraMaceState {
        int step = 0;
        int cooldownTicks = 0;
        int stuckCounter = 0;
        int lastStep = -1;
        
        // Специфичные поля для ElytraMace
        boolean elytraEquipped = false;
        int takeoffTicks = 0; // Счетчик тиков взлета
        double startY = 0; // Начальная высота для отслеживания взлета
        int waitTicks = 0; // Счетчик ожидания
        int retryCount = 0; // Счетчик попыток взлета
        
        // Слоты предметов
        int elytraSlot = -1;
        int chestplateSlot = -1;
        int fireworkSlot = -1;
        int maceSlot = -1;
    }
    
    private static final java.util.Map<String, ElytraMaceState> states = new java.util.HashMap<>();
    
    /**
     * Получить состояние бота
     */
    private static ElytraMaceState getState(String botName) {
        return states.computeIfAbsent(botName, k -> new ElytraMaceState());
    }
    
    /**
     * Проверить возможность использования ElytraMace
     */
    public static boolean canUseElytraMace(class_3222 bot, class_1297 target, BotSettings settings) {
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " checking canUseElytraMace...");
        
        if (!settings.isElytraMaceEnabled()) {
            return false;
        }
        
        double distance = bot.method_5739(target);
        if (distance > 15.0) {
            return false;
        }
        
        class_1661 inventory = bot.method_31548();
        boolean hasAllItems = hasElytra(inventory) && hasMace(inventory) && hasFireworks(inventory) && hasChestplate(inventory);
        
        // Добавим отладочную информацию
        if (!hasAllItems) {
            int elytraSlot = findElytra(inventory);
            int chestSlot = findChestplate(inventory);
            String elytraInfo = elytraSlot == 38 ? "equipped" : (elytraSlot >= 0 ? "slot " + elytraSlot : "none");
            String chestInfo = chestSlot == 38 ? "equipped" : (chestSlot >= 0 ? "slot " + chestSlot : "none");
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " missing items - Elytra: " + hasElytra(inventory) + " (" + elytraInfo + ")" +
                             ", Mace: " + hasMace(inventory) + ", Fireworks: " + hasFireworks(inventory) + 
                             ", Chestplate: " + hasChestplate(inventory) + " (" + chestInfo + ")");
        } else {
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " can use ElytraMace! Distance: " + String.format("%.1f", distance));
        }
        
        return hasAllItems;
    }
    
    /**
     * Выполнить ElytraMace трюк
     */
    public static boolean doElytraMace(class_3222 bot, class_1297 target, BotSettings settings, net.minecraft.server.MinecraftServer server) {
        ElytraMaceState state = getState(bot.method_5477().getString());
        class_1937 world = bot.method_51469();
        double distance = bot.method_5739(target);
        
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " doElytraMace called - step: " + state.step + ", distance: " + String.format("%.1f", distance));
        
        // Отладочная информация в начале каждого цикла
        if (state.step == 0 && state.cooldownTicks == 0) {
            class_1661 inventory = bot.method_31548();
            int elytraSlot = findElytra(inventory);
            int chestSlot = findChestplate(inventory);
            String elytraInfo = elytraSlot == 38 ? "equipped" : (elytraSlot >= 0 ? "slot " + elytraSlot : "none");
            String chestInfo = chestSlot == 38 ? "equipped" : (chestSlot >= 0 ? "slot " + chestSlot : "none");
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " starting new cycle - Elytra: " + elytraInfo + ", Chestplate: " + chestInfo);
        }
        
        // Проверка на застревание
        if (state.step == state.lastStep) {
            state.stuckCounter++;
            if (state.stuckCounter > 100) {
                System.out.println("[ElytraMace] " + bot.method_5477().getString() + " STUCK on step " + state.step + "! Resetting state.");
                resetState(state);
                return true;
            }
        } else {
            state.stuckCounter = 0;
            state.lastStep = state.step;
        }
        
        // Обработка кулдаунов
        if (state.cooldownTicks > 0) {
            state.cooldownTicks--;
            return true;
        }
        
        if (state.waitTicks > 0) {
            state.waitTicks--;
            return true;
        }
        
        // Если цель слишком далеко - сброс
        if (distance > 20.0) {
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " target too far, resetting");
            resetState(state);
            return true;
        }
        
        // Выполнение шагов
        switch (state.step) {
            case 0:
                return stepPrepareElytra(bot, target, state, server, world, settings);
            case 1:
                return stepTakeoff(bot, target, state, server, world, settings);
            case 2:
                return stepWaitAltitude(bot, target, state, server, world, settings);
            case 3:
                return stepRemoveElytraAndWait(bot, target, state, server, world, settings);
            case 4:
                return stepGlideToTarget(bot, target, state, server, world, settings);
            case 5:
                return stepMaceAttack(bot, target, state, server, world, settings);
            default:
                resetState(state);
                return true;
        }
    }
    
    /**
     * Шаг 0: Подготовка элитр
     */
    private static boolean stepPrepareElytra(class_3222 bot, class_1297 target, ElytraMaceState state, 
                                           net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " step 0: preparing elytra...");
        
        // Находим все необходимые предметы
        state.elytraSlot = findElytra(inventory);
        state.chestplateSlot = findChestplate(inventory);
        state.fireworkSlot = findFireworks(inventory);
        state.maceSlot = findMace(inventory);
        
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " found items - Elytra: " + state.elytraSlot + ", Chestplate: " + state.chestplateSlot + ", Fireworks: " + state.fireworkSlot + ", Mace: " + state.maceSlot);
        
        if (state.elytraSlot < 0 || state.fireworkSlot < 0 || state.maceSlot < 0) {
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " missing required items!");
            return false; // Выход из ElytraMace режима
        }
        
        // Берем элитры в руку
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " selecting elytra from slot " + state.elytraSlot);
        if (!selectItem(bot, state.elytraSlot)) {
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " failed to select elytra");
            return true;
        }
        
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " equipping elytra...");
        
        // Одеваем элитры (ПКМ)
        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " use once", 
                server.method_3739()
            );
            
            state.elytraEquipped = true;
            state.step = 1;
            state.cooldownTicks = 5;
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " elytra equipped, moving to step 1");
            
        } catch (Exception e) {
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " error equipping elytra: " + e.getMessage());
        }
        
        return true;
    }
    
    /**
     * Шаг 1: Взлет
     */
    private static boolean stepTakeoff(class_3222 bot, class_1297 target, ElytraMaceState state,
                                     net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        
        // Инициализация счетчика тиков взлета
        if (state.takeoffTicks == 0) {
            state.startY = bot.method_23318(); // Запоминаем начальную высоту
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " starting takeoff sequence at Y=" + String.format("%.1f", state.startY) + "...");
        }
        
        state.takeoffTicks++;
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " takeoff tick " + state.takeoffTicks);
        
        // Первый прыжок и установка горизонтального взгляда
        if (state.takeoffTicks == 1) {
            // Смотрим горизонтально (pitch = 0)
            bot.method_36457(0.0f);
            
            // Используем прямой вызов jump вместо команды
            bot.method_6043();
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " jumping with horizontal look (direct call)...");
        }
        
        // Активируем элитры через команду HeroBot
        if (state.takeoffTicks == 5) {
            // Используем прямой вызов jump для активации элитр
            bot.method_6043();
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " activating elytra with direct jump...");
        }
        
        // Используем фейерверки для ускорения (пока еще смотрим горизонтально)
        if (state.takeoffTicks == 8) {
            // Выбираем фейерверки
            if (!selectItem(bot, state.fireworkSlot)) {
                return true;
            }
            
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " launching with fireworks...");
            
            // Запускаем фейерверки (используем настройку количества)
            int fireworkCount = settings.getElytraMaceFireworkCount();
            try {
                for (int i = 0; i < fireworkCount; i++) {
                    server.method_3734().method_9235().execute(
                        "player " + bot.method_5477().getString() + " use once", 
                        server.method_3739()
                    );
                }
                
                System.out.println("[ElytraMace] " + bot.method_5477().getString() + " launched " + fireworkCount + " fireworks");
                
            } catch (Exception e) {
                System.out.println("[ElytraMace] " + bot.method_5477().getString() + " error launching fireworks: " + e.getMessage());
            }
        }
        
        // Теперь поворачиваем взгляд вверх для набора высоты
        if (state.takeoffTicks == 12) {
            bot.method_36457(-90.0f);
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " looking up for altitude gain");
            
            state.step = 2;
            state.cooldownTicks = 3;
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " moving to step 2");
        }
        
        return true;
    }
    
    /**
     * Шаг 2: Ждем взлета на 10-20 блоков
     */
    private static boolean stepWaitAltitude(class_3222 bot, class_1297 target, ElytraMaceState state,
                                          net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        state.takeoffTicks++;
        double currentHeight = bot.method_23318() - state.startY;
        int minAltitude = settings.getElytraMaceMinAltitude();
        
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " altitude: " + String.format("%.1f", currentHeight) + " blocks (tick " + state.takeoffTicks + ")");
        
        // Проверяем успешный взлет
        if (currentHeight >= minAltitude) {
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " reached altitude " + String.format("%.1f", currentHeight) + ", moving to step 3");
            state.step = 3;
            state.cooldownTicks = 0;
            return true;
        }
        
        // Проверяем неудачный взлет (таймаут или падение)
        if (state.takeoffTicks >= 80 || (state.takeoffTicks > 20 && currentHeight < 2.0)) {
            state.retryCount++;
            int maxRetries = settings.getElytraMaceMaxRetries();
            
            if (state.retryCount < maxRetries) {
                System.out.println("[ElytraMace] " + bot.method_5477().getString() + " takeoff failed (altitude: " + String.format("%.1f", currentHeight) + "), retry " + state.retryCount + "/" + maxRetries);
                // Сбрасываем к шагу 0 для повторной попытки
                state.step = 0;
                state.takeoffTicks = 0;
                state.elytraEquipped = false;
                state.cooldownTicks = 10; // Небольшая пауза перед повтором
            } else {
                System.out.println("[ElytraMace] " + bot.method_5477().getString() + " takeoff failed after " + maxRetries + " attempts, giving up");
                resetState(state);
                return false; // Выходим из ElytraMace режима
            }
        }
        
        return true;
    }
    
    /**
     * Шаг 3: Снимаем элитры и ждем
     */
    private static boolean stepRemoveElytraAndWait(class_3222 bot, class_1297 target, ElytraMaceState state,
                                                 net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        
        // Выбираем нагрудник
        if (state.chestplateSlot >= 0) {
            // Если нагрудник уже надет (слот 38), не нужно его выбирать
            if (state.chestplateSlot != 38) {
                if (!selectItem(bot, state.chestplateSlot)) {
                    return true;
                }
            }
            
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " equipping chestplate...");
            
            // Одеваем нагрудник (ПКМ) - это снимет элитры
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " use once", 
                    server.method_3739()
                );
            } catch (Exception e) {
                System.out.println("[ElytraMace] " + bot.method_5477().getString() + " error equipping chestplate: " + e.getMessage());
            }
        } else {
            // Если нагрудника нет, просто снимаем элитры
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " no chestplate, removing elytra manually...");
            // Можно попробовать снять элитры другим способом, но пока пропустим
        }
        
        state.elytraEquipped = false;
        state.waitTicks = 5; // Ждем 5 тиков
        state.step = 4;
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " elytra removed, waiting 5 ticks");
        
        return true;
    }
    
    /**
     * Шаг 4: Планирование к цели
     */
    private static boolean stepGlideToTarget(class_3222 bot, class_1297 target, ElytraMaceState state,
                                           net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        double distance = bot.method_5739(target);
        
        // Одеваем элитры обратно
        if (!state.elytraEquipped) {
            if (!selectItem(bot, state.elytraSlot)) {
                return true;
            }
            
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " re-equipping elytra for glide...");
            
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " use once", 
                    server.method_3739()
                );
                state.elytraEquipped = true;
            } catch (Exception e) {
                System.out.println("[ElytraMace] " + bot.method_5477().getString() + " error re-equipping elytra: " + e.getMessage());
            }
            return true;
        }
        
        // Улучшенное прицеливание - смотрим на цель с учетом движения
        lookAtEntity(bot, target);
        
        // Вычисляем угол для планирования к цели
        double deltaX = target.method_23317() - bot.method_23317();
        double deltaY = target.method_23318() - bot.method_23318();
        double deltaZ = target.method_23321() - bot.method_23321();
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        
        // Устанавливаем pitch для планирования (не прямо вниз, а под углом к цели)
        float targetPitch = (float) Math.toDegrees(Math.atan2(deltaY, horizontalDistance));
        // Ограничиваем pitch от 30 до 90 градусов (вниз)
        targetPitch = Math.max(30.0f, Math.min(90.0f, targetPitch));
        bot.method_36457(targetPitch);
        
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " gliding to target, distance: " + String.format("%.1f", distance) + ", pitch: " + String.format("%.1f", targetPitch));
        
        // Проверяем дистанцию до цели
        double attackDistance = settings.getElytraMaceAttackDistance();
        if (distance <= attackDistance) {
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " close to target (" + String.format("%.1f", distance) + "), moving to step 5");
            state.step = 5;
            state.cooldownTicks = 0;
        }
        
        return true;
    }
    
    /**
     * Шаг 5: Атака булавой
     */
    private static boolean stepMaceAttack(class_3222 bot, class_1297 target, ElytraMaceState state,
                                        net.minecraft.server.MinecraftServer server, class_1937 world, BotSettings settings) {
        class_1661 inventory = bot.method_31548();
        
        // Снимаем элитры (одеваем нагрудник)
        if (state.elytraEquipped && state.chestplateSlot >= 0) {
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " removing elytra, chestplate slot: " + state.chestplateSlot);
            
            // Если нагрудник уже надет (слот 38), не нужно его выбирать
            if (state.chestplateSlot != 38) {
                if (!selectItem(bot, state.chestplateSlot)) {
                    return true;
                }
            }
            
            try {
                server.method_3734().method_9235().execute(
                    "player " + bot.method_5477().getString() + " use once", 
                    server.method_3739()
                );
                state.elytraEquipped = false;
                
                // Проверяем где теперь элитры
                int elytraSlot = findElytra(inventory);
                String elytraInfo = elytraSlot == 38 ? "still equipped" : (elytraSlot >= 0 ? "moved to slot " + elytraSlot : "disappeared");
                System.out.println("[ElytraMace] " + bot.method_5477().getString() + " elytra removed for mace attack, elytra now: " + elytraInfo);
            } catch (Exception e) {
                System.out.println("[ElytraMace] " + bot.method_5477().getString() + " error removing elytra: " + e.getMessage());
            }
            return true;
        }
        
        // Выбираем булаву
        if (!selectItem(bot, state.maceSlot)) {
            return true;
        }
        
        // Смотрим на цель
        lookAtEntity(bot, target);
        
        // Спамим атаку булавой
        System.out.println("[ElytraMace] " + bot.method_5477().getString() + " attacking with mace!");
        
        try {
            server.method_3734().method_9235().execute(
                "player " + bot.method_5477().getString() + " attack once", 
                server.method_3739()
            );
        } catch (Exception e) {
            System.out.println("[ElytraMace] " + bot.method_5477().getString() + " error attacking with mace: " + e.getMessage());
            bot.method_6104(class_1268.field_5808);
        }
        
        // Сброс состояния для повтора цикла
        resetState(state);
        state.cooldownTicks = 20; // Кулдаун перед следующим циклом
        
        return true;
    }
    
    /**
     * Сброс состояния
     */
    private static void resetState(ElytraMaceState state) {
        state.step = 0;
        state.elytraEquipped = false;
        state.takeoffTicks = 0;
        state.startY = 0;
        state.waitTicks = 0;
        state.stuckCounter = 0;
        state.lastStep = -1;
        state.retryCount = 0; // Сбрасываем счетчик попыток
        state.elytraSlot = -1;
        state.chestplateSlot = -1;
        state.fireworkSlot = -1;
        state.maceSlot = -1;
    }
    
    /**
     * Смотреть на сущность
     */
    private static void lookAtEntity(class_3222 bot, class_1297 target) {
        double dx = target.method_23317() - bot.method_23317();
        double dy = target.method_23318() - bot.method_23318();
        double dz = target.method_23321() - bot.method_23321();
        
        double distance = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90.0f;
        float pitch = (float) (Math.atan2(dy, distance) * 180.0 / Math.PI);
        
        bot.method_36456(yaw);
        bot.method_36457(-pitch);
    }
    
    /**
     * Выбрать предмет в слоте
     */
    private static boolean selectItem(class_3222 bot, int slot) {
        if (slot < 0 || slot >= 36) return false;
        
        class_1661 inventory = bot.method_31548();
        
        // Если предмет не в хотбаре, перемещаем его
        if (slot >= 9) {
            class_1799 item = inventory.method_5438(slot);
            class_1799 current = inventory.method_5438(8);
            inventory.method_5447(slot, current);
            inventory.method_5447(8, item);
            slot = 8;
        }
        
        org.stepan1411.pvp_bot.utils.InventoryHelper.setSelectedSlot(inventory, slot);
        return true;
    }
    
    /**
     * Найти элитры в инвентаре или проверить что они уже надеты
     */
    private static int findElytra(class_1661 inventory) {
        // Сначала проверяем, надеты ли уже элитры (слот 38)
        class_1799 equippedChest = inventory.method_5438(38);
        if (!equippedChest.method_7960() && equippedChest.method_7909() == class_1802.field_8833) {
            return 38; // Возвращаем слот брони
        }
        
        // Если не надеты, ищем в обычном инвентаре
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8833) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Найти нагрудник в инвентаре
     */
    /**
     * Найти нагрудник в инвентаре или проверить что он уже надет
     */
    private static int findChestplate(class_1661 inventory) {
        // Сначала проверяем, надет ли уже нагрудник (слот 38)
        class_1799 equippedChest = inventory.method_5438(38);
        if (!equippedChest.method_7960()) {
            String itemName = equippedChest.method_7909().toString().toLowerCase();
            if (itemName.contains("chestplate")) {
                return 38; // Возвращаем слот брони
            }
        }
        
        // Если не надет, ищем в обычном инвентаре
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            String itemName = stack.method_7909().toString().toLowerCase();
            if (itemName.contains("chestplate")) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Найти фейерверки в инвентаре
     */
    private static int findFireworks(class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_8639) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Найти булаву в инвентаре
     */
    private static int findMace(class_1661 inventory) {
        for (int i = 0; i < 36; i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7909() == class_1802.field_49814) {
                return i;
            }
        }
        return -1;
    }
    
    /**
     * Проверить наличие элитр
     */
    private static boolean hasElytra(class_1661 inventory) {
        return findElytra(inventory) >= 0;
    }
    
    /**
     * Проверить наличие булавы
     */
    private static boolean hasMace(class_1661 inventory) {
        return findMace(inventory) >= 0;
    }
    
    /**
     * Проверить наличие фейерверков
     */
    private static boolean hasFireworks(class_1661 inventory) {
        return findFireworks(inventory) >= 0;
    }
    
    /**
     * Проверить наличие нагрудника
     */
    private static boolean hasChestplate(class_1661 inventory) {
        return findChestplate(inventory) >= 0;
    }
    
    /**
     * Сброс состояния бота
     */
    public static void reset(String botName) {
        ElytraMaceState state = states.get(botName);
        if (state != null) {
            resetState(state);
        }
    }
}