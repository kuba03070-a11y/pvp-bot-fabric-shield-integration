package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;

/**
 * Stub implementation of BotBaritone.
 * The custom A* pathfinding has been removed; all movement falls back to
 * BotNavigation's built-in direct movement which is stable and well-tested.
 */
public class BotBaritone {

    private static final Map<String, class_243> gotoTargets = new HashMap<>();

    public static boolean isBaritoneAvailable(class_3222 bot) {
        return true;
    }

    public static boolean goToPosition(class_3222 bot, class_243 targetPos) {
        String botName = bot.method_5477().getString();
        gotoTargets.put(botName, targetPos);
        // Create a temporary entity-like target using direct navigation
        double dist = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321()).method_1022(targetPos);
        if (dist < 1.5) {
            gotoTargets.remove(botName);
            return false; // arrived
        }
        BotNavigation.moveTowardPosition(bot, targetPos, BotSettings.get().getMoveSpeed());
        return true;
    }

    public static boolean goToEntity(class_3222 bot, class_1297 target, double distance) {
        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        double dist = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321()).method_1022(targetPos);
        if (dist <= distance) return false;
        BotNavigation.moveToward(bot, target, BotSettings.get().getMoveSpeed());
        return true;
    }

    public static boolean moveAwayFrom(class_3222 bot, class_1297 target, double minDistance) {
        double dist = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321()).method_1022(new class_243(target.method_23317(), target.method_23318(), target.method_23321()));
        if (dist >= minDistance) return false;
        BotNavigation.moveAway(bot, target, BotSettings.get().getMoveSpeed());
        return true;
    }

    public static void stop(class_3222 bot) {
        gotoTargets.remove(bot.method_5477().getString());
    }

    public static boolean isPathing(class_3222 bot) {
        return gotoTargets.containsKey(bot.method_5477().getString());
    }

    public static double getDistanceToGoal(class_3222 bot) {
        class_243 goal = gotoTargets.get(bot.method_5477().getString());
        if (goal == null) return -1;
        return new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321()).method_1022(goal);
    }

    public static void removeBaritone(String botName) {
        gotoTargets.remove(botName);
    }
}
