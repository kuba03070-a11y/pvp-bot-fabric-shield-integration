package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.stepan1411.pvp_bot.bot.pathfinding.AStarPathfinder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class BotBaritone {
    
    private static final Map<String, PathState> pathStates = new HashMap<>();
    

    private static final Map<String, GroupPathCache> groupPathCache = new HashMap<>();
    

    private static final Map<String, Long> failedPathCache = new HashMap<>();
    private static final long FAILED_PATH_CACHE_TIME = 3000;
    
    private static final double GROUP_RADIUS = 5.0;
    
    private static class PathState {
        List<class_243> currentPath;
        int currentIndex;
        class_243 targetPos;
        long lastPathTime;
        
        PathState(List<class_243> path, class_243 target) {
            this.currentPath = path;
            this.currentIndex = 0;
            this.targetPos = target;
            this.lastPathTime = System.currentTimeMillis();
        }
    }
    
    private static class GroupPathCache {
        List<class_243> path;
        class_243 groupStartPos;
        class_243 targetPos;
        long cacheTime;
        
        GroupPathCache(List<class_243> path, class_243 groupStartPos, class_243 targetPos) {
            this.path = path;
            this.groupStartPos = groupStartPos;
            this.targetPos = targetPos;
            this.cacheTime = System.currentTimeMillis();
        }
        
        boolean isValid(class_243 botPos, class_243 currentTarget) {

            if (System.currentTimeMillis() - cacheTime > 5000) {
                return false;
            }

            if (botPos.method_1022(groupStartPos) > GROUP_RADIUS) {
                return false;
            }

            if (!targetPos.method_24802(currentTarget, 2.0)) {
                return false;
            }
            return true;
        }
    }
    
    
    public static boolean isBaritoneAvailable(class_3222 bot) {
        return true;
    }
    
    
    public static boolean goToPosition(class_3222 bot, class_243 targetPos) {
        String botName = bot.method_5477().getString();
        PathState state = pathStates.get(botName);
        class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
        

        boolean needNewPath = state == null || 
                              state.currentPath == null || 
                              state.currentIndex >= state.currentPath.size() ||
                              !state.targetPos.method_24802(targetPos, 2.0) ||
                              System.currentTimeMillis() - state.lastPathTime > 5000;
        
        if (needNewPath) {
            List<class_243> path = null;
            

            String failKey = generateGroupKey(botPos, targetPos);
            Long lastFailTime = failedPathCache.get(failKey);
            if (lastFailTime != null && System.currentTimeMillis() - lastFailTime < FAILED_PATH_CACHE_TIME) {

                path = new java.util.ArrayList<>();
                path.add(targetPos);
            } else {

                String groupKey = generateGroupKey(botPos, targetPos);
                GroupPathCache cachedGroup = groupPathCache.get(groupKey);
                
                if (cachedGroup != null && cachedGroup.isValid(botPos, targetPos)) {

                    path = cachedGroup.path;
                    System.out.println("[BotBaritone] " + botName + " using cached group path with " + path.size() + " waypoints");
                } else {

                    path = AStarPathfinder.findPath(bot, targetPos);
                    
                    if (path == null || path.isEmpty()) {

                        failedPathCache.put(failKey, System.currentTimeMillis());
                        path = new java.util.ArrayList<>();
                        path.add(targetPos);
                        

                        if (lastFailTime == null) {
                            System.out.println("[BotBaritone] No path found for " + botName + ", using direct path (cached for 3s)");
                        }
                    } else {

                        System.out.println("[BotBaritone] Calculated new path for " + botName + " with " + path.size() + " waypoints");
                        

                        groupPathCache.put(groupKey, new GroupPathCache(path, botPos, targetPos));
                        

                        if (groupPathCache.size() > 20) {
                            cleanOldGroupCache();
                        }
                    }
                }
            }
            
            state = new PathState(path, targetPos);
            pathStates.put(botName, state);
        }
        

        if (state.currentIndex < state.currentPath.size()) {
            class_243 nextPoint = state.currentPath.get(state.currentIndex);

            

            if (BotDebug.isEnabled(botName)) {
                BotDebug.showPath(bot, targetPos, new java.util.LinkedList<>(), state.currentPath);
            }
            

            double horizontalDist = Math.sqrt(
                Math.pow(nextPoint.field_1352 - botPos.field_1352, 2) + 
                Math.pow(nextPoint.field_1350 - botPos.field_1350, 2)
            );
            double verticalDist = Math.abs(nextPoint.field_1351 - botPos.field_1351);
            

            if (horizontalDist < 0.5 && verticalDist < 1.0) {
                state.currentIndex++;
                if (state.currentIndex >= state.currentPath.size()) {

                    return true;
                }
                nextPoint = state.currentPath.get(state.currentIndex);
            }
            

            BotNavigation.NavigationState navState = BotNavigation.getState(bot.method_5477().getString());
            if (navState.jumpCooldown > 0) navState.jumpCooldown--;
            if (navState.avoidTicks > 0) navState.avoidTicks--;
            

            double dx = nextPoint.field_1352 - botPos.field_1352;
            double dz = nextPoint.field_1350 - botPos.field_1350;
            double dist = Math.sqrt(dx * dx + dz * dz);
            
            if (dist > 0.1) {
                double dy = nextPoint.field_1351 - botPos.field_1351;
                

                dx /= dist;
                dz /= dist;
                

                double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
                float yawF = (float) yaw;
                

                float currentYaw = bot.method_36454();
                float yawDiff = yawF - currentYaw;
                

                while (yawDiff > 180) yawDiff -= 360;
                while (yawDiff < -180) yawDiff += 360;
                

                if (Math.abs(yawDiff) > 30) {
                    yawF = currentYaw + Math.signum(yawDiff) * 30;
                }
                
                bot.method_36456(yawF);
                bot.method_5847(yawF);
                

                if (HerobotMovement.isHerobotAvailable()) {
                    MinecraftServer server = bot.method_64396().method_9211();
                    

                    HerobotMovement.executeCommand(server, String.format("player %s move forward", botName));
                    

                    if (dist > 3.0) {
                        HerobotMovement.executeCommand(server, String.format("player %s sprint", botName));
                    }
                    

                    BotSettings settings = BotSettings.get();
                    if (bot.method_24828() && navState.jumpCooldown <= 0) {
                        if (dy > 0.5) {

                            HerobotMovement.executeCommand(server, String.format("player %s jump", botName));
                            navState.jumpCooldown = 10;
                        } else if (settings.isBhopEnabled() && dist > 2.0) {

                            HerobotMovement.executeCommand(server, String.format("player %s jump", botName));
                            navState.jumpCooldown = settings.getBhopCooldown();
                        }
                    }
                } else {


                    double speed = 0.1;
                    

                    double currentVelX = bot.method_18798().field_1352;
                    double currentVelZ = bot.method_18798().field_1350;
                    

                    double targetVelX = dx * speed;
                    double targetVelZ = dz * speed;
                    

                    double newVelX = currentVelX * 0.8 + targetVelX * 0.2;
                    double newVelZ = currentVelZ * 0.8 + targetVelZ * 0.2;
                    

                    bot.method_18800(newVelX, bot.method_18798().field_1351, newVelZ);
                    

                    bot.method_5728(true);
                    

                    BotSettings settings = BotSettings.get();
                    if (bot.method_24828() && navState.jumpCooldown <= 0) {
                        if (dy > 0.5) {
                            bot.method_6043();
                            navState.jumpCooldown = 10;
                        } else if (settings.isBhopEnabled() && dist > 2.0) {
                            bot.method_6043();
                            navState.jumpCooldown = settings.getBhopCooldown();
                        }
                    }
                }
            }
            
            return true;
        }
        
        return false;
    }
    
    
    public static boolean goToEntity(class_3222 bot, class_1297 target, double distance) {
        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        return goToPosition(bot, targetPos);
    }
    
    
    public static boolean moveAwayFrom(class_3222 bot, class_1297 target, double minDistance) {

        return false;
    }
    
    
    public static void stop(class_3222 bot) {
        String botName = bot.method_5477().getString();
        pathStates.remove(botName);
    }
    
    
    public static boolean isPathing(class_3222 bot) {
        String botName = bot.method_5477().getString();
        PathState state = pathStates.get(botName);
        return state != null && state.currentPath != null && state.currentIndex < state.currentPath.size();
    }
    
    
    public static double getDistanceToGoal(class_3222 bot) {
        String botName = bot.method_5477().getString();
        PathState state = pathStates.get(botName);
        if (state == null || state.targetPos == null) {
            return -1;
        }
        class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
        return botPos.method_1022(state.targetPos);
    }
    
    
    public static void removeBaritone(String botName) {
        pathStates.remove(botName);
    }
    
    
    private static String generateGroupKey(class_243 botPos, class_243 targetPos) {

        int gridX = (int) Math.floor(botPos.field_1352 / GROUP_RADIUS);
        int gridY = (int) Math.floor(botPos.field_1351 / GROUP_RADIUS);
        int gridZ = (int) Math.floor(botPos.field_1350 / GROUP_RADIUS);
        

        int targetX = (int) Math.floor(targetPos.field_1352);
        int targetY = (int) Math.floor(targetPos.field_1351);
        int targetZ = (int) Math.floor(targetPos.field_1350);
        
        return String.format("%d_%d_%d_to_%d_%d_%d", gridX, gridY, gridZ, targetX, targetY, targetZ);
    }
    
    
    private static void cleanOldGroupCache() {
        long currentTime = System.currentTimeMillis();
        groupPathCache.entrySet().removeIf(entry -> 
            currentTime - entry.getValue().cacheTime > 5000
        );
        

        failedPathCache.entrySet().removeIf(entry ->
            currentTime - entry.getValue() > FAILED_PATH_CACHE_TIME
        );
    }
}
