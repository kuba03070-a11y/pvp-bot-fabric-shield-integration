package org.stepan1411.pvp_bot.bot;

import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_2390;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;


public class BotDebug {
    

    private static final int COLOR_GREEN = 0x00FF00;
    private static final int COLOR_GRAY = 0x808080;
    private static final int COLOR_RED = 0xFF0000;
    private static final int COLOR_PURPLE = 0xFF00FF;
    private static final int COLOR_BLUE = 0x0080FF;
    private static final int COLOR_YELLOW = 0xFFFF00;
    

    private static final Map<String, DebugSettings> debugSettings = new HashMap<>();
    
    
    public static class DebugSettings {
        public boolean pathVisualization = false;
        public boolean targetVisualization = false;
        public boolean combatInfo = false;
        public boolean navigationInfo = false;
        

        public int pathTickCounter = 0;
        public int targetTickCounter = 0;
        public int navigationTickCounter = 0;
        
        public boolean isAnyEnabled() {
            return pathVisualization || targetVisualization || combatInfo || navigationInfo;
        }
    }
    
    public static DebugSettings getSettings(String botName) {
        return debugSettings.computeIfAbsent(botName, k -> new DebugSettings());
    }
    
    public static void setPathVisualization(String botName, boolean enabled) {
        getSettings(botName).pathVisualization = enabled;
    }
    
    public static void setTargetVisualization(String botName, boolean enabled) {
        getSettings(botName).targetVisualization = enabled;
    }
    
    public static void setCombatInfo(String botName, boolean enabled) {
        getSettings(botName).combatInfo = enabled;
    }
    
    public static void setNavigationInfo(String botName, boolean enabled) {
        getSettings(botName).navigationInfo = enabled;
    }
    
    public static void enableAll(String botName) {
        DebugSettings settings = getSettings(botName);
        settings.pathVisualization = true;
        settings.targetVisualization = true;
        settings.combatInfo = true;
        settings.navigationInfo = true;
    }
    
    public static void disableAll(String botName) {
        debugSettings.remove(botName);
    }
    
    public static boolean isEnabled(String botName) {
        DebugSettings settings = debugSettings.get(botName);
        return settings != null && settings.isAnyEnabled();
    }
    
    
    public static void showPath(class_3222 bot, class_243 targetPos, java.util.LinkedList<class_243> pathHistory) {
        showPath(bot, targetPos, pathHistory, null);
    }
    
    
    public static void showPath(class_3222 bot, class_243 targetPos, java.util.LinkedList<class_243> pathHistory, List<class_243> fullPath) {
        DebugSettings settings = getSettings(bot.method_5477().getString());
        if (!settings.pathVisualization) {
            return;
        }
        

        settings.pathTickCounter++;
        if (settings.pathTickCounter < 5) {
            return;
        }
        settings.pathTickCounter = 0;
        
        class_3218 world = (class_3218) bot.method_51469();
        

        class_2390 greenDust = new class_2390(COLOR_GREEN, 1.0f);
        class_2390 grayDust = new class_2390(COLOR_GRAY, 0.7f);
        class_2390 blueDust = new class_2390(COLOR_BLUE, 1.0f);
        

        if (fullPath != null && !fullPath.isEmpty()) {

            for (class_243 waypoint : fullPath) {
                world.method_65096(blueDust, waypoint.field_1352, waypoint.field_1351 + 0.5, waypoint.field_1350, 3, 0.2, 0.2, 0.2, 0);
            }
            

            for (int i = 0; i < fullPath.size() - 1; i++) {
                class_243 pos1 = fullPath.get(i);
                class_243 pos2 = fullPath.get(i + 1);
                
                drawLine(world, blueDust, 
                    pos1.field_1352, pos1.field_1351 + 0.3, pos1.field_1350, 
                    pos2.field_1352, pos2.field_1351 + 0.3, pos2.field_1350, 
                    0.3);
            }
            
            return;
        }
        

        List<class_243> allPositions = new ArrayList<>(pathHistory);
        class_243 currentPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
        
        if (allPositions.isEmpty() || currentPos.method_1022(allPositions.get(allPositions.size() - 1)) > 0.3) {
            allPositions.add(currentPos);
        }
        
        allPositions.add(targetPos);
        
        if (allPositions.isEmpty()) {
            return;
        }
        

        Set<class_2338> uniqueBlocks = new LinkedHashSet<>();
        for (class_243 pos : allPositions) {
            class_2338 blockPos = new class_2338(
                (int) Math.floor(pos.field_1352), 
                (int) Math.floor(pos.field_1351), 
                (int) Math.floor(pos.field_1350)
            );
            uniqueBlocks.add(blockPos);
        }
        

        for (class_2338 blockPos : uniqueBlocks) {
            int bx = blockPos.method_10263();
            int by = blockPos.method_10264();
            int bz = blockPos.method_10260();
            
            world.method_65096(greenDust, bx, by + 1, bz, 1, 0, 0, 0, 0);
            world.method_65096(greenDust, bx + 1, by + 1, bz + 1, 1, 0, 0, 0, 0);
        }
        

        if (allPositions.size() > 1) {
            for (int i = 0; i < allPositions.size() - 1; i++) {
                class_243 pos1 = allPositions.get(i);
                class_243 pos2 = allPositions.get(i + 1);
                
                drawLine(world, grayDust, 
                    pos1.field_1352, pos1.field_1351 + 0.1, pos1.field_1350, 
                    pos2.field_1352, pos2.field_1351 + 0.1, pos2.field_1350, 
                    0.3);
            }
        }
    }
    
    
    public static void showTargetBlock(class_3222 bot, class_243 targetPos) {
        DebugSettings settings = getSettings(bot.method_5477().getString());
        if (!settings.navigationInfo) {
            return;
        }
        
        settings.navigationTickCounter++;
        if (settings.navigationTickCounter < 5) {
            return;
        }
        settings.navigationTickCounter = 0;
        
        class_3218 world = (class_3218) bot.method_51469();
        
        int blockX = (int) Math.floor(targetPos.field_1352);
        int blockY = (int) Math.floor(targetPos.field_1351);
        int blockZ = (int) Math.floor(targetPos.field_1350);
        
        class_2390 redDust = new class_2390(COLOR_RED, 1.0f);
        
        double step = 0.2;
        

        drawLine(world, redDust, blockX, blockY, blockZ, blockX + 1, blockY, blockZ, step);
        drawLine(world, redDust, blockX, blockY, blockZ + 1, blockX + 1, blockY, blockZ + 1, step);
        drawLine(world, redDust, blockX, blockY, blockZ, blockX, blockY, blockZ + 1, step);
        drawLine(world, redDust, blockX + 1, blockY, blockZ, blockX + 1, blockY, blockZ + 1, step);
        

        drawLine(world, redDust, blockX, blockY + 1, blockZ, blockX + 1, blockY + 1, blockZ, step);
        drawLine(world, redDust, blockX, blockY + 1, blockZ + 1, blockX + 1, blockY + 1, blockZ + 1, step);
        drawLine(world, redDust, blockX, blockY + 1, blockZ, blockX, blockY + 1, blockZ + 1, step);
        drawLine(world, redDust, blockX + 1, blockY + 1, blockZ, blockX + 1, blockY + 1, blockZ + 1, step);
        

        drawLine(world, redDust, blockX, blockY, blockZ, blockX, blockY + 1, blockZ, step);
        drawLine(world, redDust, blockX + 1, blockY, blockZ, blockX + 1, blockY + 1, blockZ, step);
        drawLine(world, redDust, blockX, blockY, blockZ + 1, blockX, blockY + 1, blockZ + 1, step);
        drawLine(world, redDust, blockX + 1, blockY, blockZ + 1, blockX + 1, blockY + 1, blockZ + 1, step);
    }
    
    
    public static void showTargetEntity(class_3222 bot, net.minecraft.class_1297 target) {
        DebugSettings settings = getSettings(bot.method_5477().getString());
        if (!settings.targetVisualization) {
            return;
        }
        
        settings.targetTickCounter++;
        if (settings.targetTickCounter < 3) {
            return;
        }
        settings.targetTickCounter = 0;
        
        class_3218 world = (class_3218) bot.method_51469();
        var box = target.method_5829();
        
        class_2390 purpleDust = new class_2390(COLOR_PURPLE, 1.0f);
        double step = 0.2;
        

        drawLine(world, purpleDust, box.field_1323, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1321, step);
        drawLine(world, purpleDust, box.field_1323, box.field_1322, box.field_1324, box.field_1320, box.field_1322, box.field_1324, step);
        drawLine(world, purpleDust, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1322, box.field_1324, step);
        drawLine(world, purpleDust, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1322, box.field_1324, step);
        

        drawLine(world, purpleDust, box.field_1323, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1321, step);
        drawLine(world, purpleDust, box.field_1323, box.field_1325, box.field_1324, box.field_1320, box.field_1325, box.field_1324, step);
        drawLine(world, purpleDust, box.field_1323, box.field_1325, box.field_1321, box.field_1323, box.field_1325, box.field_1324, step);
        drawLine(world, purpleDust, box.field_1320, box.field_1325, box.field_1321, box.field_1320, box.field_1325, box.field_1324, step);
        

        drawLine(world, purpleDust, box.field_1323, box.field_1322, box.field_1321, box.field_1323, box.field_1325, box.field_1321, step);
        drawLine(world, purpleDust, box.field_1320, box.field_1322, box.field_1321, box.field_1320, box.field_1325, box.field_1321, step);
        drawLine(world, purpleDust, box.field_1323, box.field_1322, box.field_1324, box.field_1323, box.field_1325, box.field_1324, step);
        drawLine(world, purpleDust, box.field_1320, box.field_1322, box.field_1324, box.field_1320, box.field_1325, box.field_1324, step);
    }
    
    
    private static void drawLine(class_3218 world, class_2390 dust, double x1, double y1, double z1, double x2, double y2, double z2, double step) {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double dz = z2 - z1;
        double length = Math.sqrt(dx * dx + dy * dy + dz * dz);
        int steps = (int) Math.ceil(length / step);
        
        for (int i = 0; i <= steps; i++) {
            double t = i / (double) steps;
            double x = x1 + dx * t;
            double y = y1 + dy * t;
            double z = z1 + dz * t;
            
            world.method_65096(dust, x, y, z, 1, 0, 0, 0, 0);
        }
    }
    
    public static void clearAll() {
        debugSettings.clear();
    }
}
