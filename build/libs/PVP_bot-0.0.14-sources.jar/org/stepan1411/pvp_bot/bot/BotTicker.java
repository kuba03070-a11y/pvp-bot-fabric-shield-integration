package org.stepan1411.pvp_bot.bot;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class BotTicker {

    private static int tickCounter = 0;
    private static int autoSaveCounter = 0;
    private static final int AUTO_SAVE_INTERVAL = 1200;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(BotTicker::onServerTick);
    }

    private static void onServerTick(MinecraftServer server) {
        tickCounter++;
        autoSaveCounter++;
        
        int interval = BotSettings.get().getCheckInterval();
        

        if (tickCounter % 20 == 0) {
            BotManager.cleanupDeadBots(server);

        }
        


        if (autoSaveCounter >= AUTO_SAVE_INTERVAL) {
            BotManager.updateBotData(server);
            BotManager.saveBots();
            autoSaveCounter = 0;
        }
        

        BotPathVisualizer.update(server);
        
        for (String botName : BotManager.getAllBots()) {
            class_3222 bot = BotManager.getBot(server, botName);
            if (bot != null && bot.method_5805()) {

                try {
                    org.stepan1411.pvp_bot.api.PvpBotAPI.getEventManager().fireTickEvent(bot);
                } catch (Exception e) {
                    System.err.println("[PVP_BOT_API] Error firing tick event: " + e.getMessage());
                }

                BotUtils.update(bot, server);
                

                BotMovement.updateMovement(bot);
                

                boolean isFollowingWithoutAttack = BotPath.isFollowing(botName) && !BotPath.shouldAttack(botName);
                if (!isFollowingWithoutAttack) {
                    BotCombat.update(bot, server);
                }
                

                if (BotPath.isFollowing(botName)) {
                    boolean shouldAttack = BotPath.shouldAttack(botName);
                    var target = BotCombat.getTarget(botName);
                    boolean hasTarget = target != null && target.method_5805();
                    

                    if (shouldAttack && hasTarget) {
                        class_243 nextPoint = BotPath.getNextPoint(botName);
                        

                        if (!BotPath.isInCombat(botName)) {
                            BotPath.startCombat(botName, nextPoint);
                        }
                        


                        
                    } else {

                        

                        if (BotPath.isInCombat(botName)) {
                            BotPath.endCombat(botName);
                        }
                        

                        class_243 pausedPoint = BotPath.getPausedPoint(botName);
                        if (pausedPoint != null) {
                            class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
                            double distanceToPaused = botPos.method_1022(pausedPoint);
                            

                            if (distanceToPaused < 1.5) {
                                BotPath.clearPausedPoint(botName);
                            } else {

                                BotNavigation.lookAtPosition(bot, pausedPoint);
                                BotNavigation.moveTowardPosition(bot, pausedPoint, 1.0);
                            }
                        } else {

                            class_243 nextPoint = BotPath.getNextPoint(botName);
                            if (nextPoint != null) {
                                class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
                                double distance = botPos.method_1022(nextPoint);
                                

                                if (distance < 1.5) {
                                    BotPath.advanceToNextPoint(botName);
                                } else {

                                    BotNavigation.lookAtPosition(bot, nextPoint);
                                    BotNavigation.moveTowardPosition(bot, nextPoint, 1.0);
                                }
                            }
                        }
                    }
                }
                

                if (tickCounter >= interval) {
                    var utilsState = BotUtils.getState(botName);
                    if (!utilsState.isEating) {
                        BotEquipment.autoEquip(bot);
                    }
                }
            }
        }
        
        if (tickCounter >= interval) {
            tickCounter = 0;
        }
    }
}
