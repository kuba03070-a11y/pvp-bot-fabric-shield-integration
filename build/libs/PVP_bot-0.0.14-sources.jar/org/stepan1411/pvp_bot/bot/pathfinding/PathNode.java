package org.stepan1411.pvp_bot.bot.pathfinding;

import net.minecraft.class_2338;


public class PathNode implements Comparable<PathNode> {
    public final class_2338 pos;
    public final long hash;
    
    public PathNode parent;
    public double cost;
    public double estimatedCost;
    public double combinedCost;
    
    public PathNode(class_2338 pos, PathNode parent, double cost, double estimatedCost) {
        this.pos = pos;
        this.hash = pos.method_10063();
        this.parent = parent;
        this.cost = cost;
        this.estimatedCost = estimatedCost;
        this.combinedCost = cost + estimatedCost;
    }
    
    @Override
    public int compareTo(PathNode other) {
        return Double.compare(this.combinedCost, other.combinedCost);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof PathNode)) return false;
        return this.hash == ((PathNode) obj).hash;
    }
    
    @Override
    public int hashCode() {
        return Long.hashCode(hash);
    }
}
