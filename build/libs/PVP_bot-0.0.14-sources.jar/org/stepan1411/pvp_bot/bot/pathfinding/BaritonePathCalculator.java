package org.stepan1411.pvp_bot.bot.pathfinding;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_243;
import net.minecraft.class_3222;


public class BaritonePathCalculator {
    
    private static boolean baritoneAvailable = false;
    
    static {
        try {

            Class.forName("baritone.api.BaritoneAPI");
            baritoneAvailable = true;
        } catch (ClassNotFoundException e) {
            baritoneAvailable = false;
        }
    }
    
    
    public static List<class_243> calculatePath(class_3222 bot, class_243 targetPos) {



        return AStarPathfinder.findPath(bot, targetPos);
    }
    
    
    public static boolean isBaritoneAvailable() {
        return baritoneAvailable;
    }
    
    
    private static List<class_243> tryBaritonePathfinding(class_3222 bot, class_243 targetPos) {





        

        return null;
    }
}
