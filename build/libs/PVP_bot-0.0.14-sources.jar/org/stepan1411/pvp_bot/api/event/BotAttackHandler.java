package org.stepan1411.pvp_bot.api.event;

import net.minecraft.class_1297;
import net.minecraft.class_3222;


@FunctionalInterface
public interface BotAttackHandler {
    
    boolean onBotAttack(class_3222 bot, class_1297 target);
}
