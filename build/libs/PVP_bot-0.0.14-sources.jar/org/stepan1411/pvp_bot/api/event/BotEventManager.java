package org.stepan1411.pvp_bot.api.event;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_3222;


public class BotEventManager {
    
    private static final BotEventManager INSTANCE = new BotEventManager();
    
    private final List<BotSpawnHandler> spawnHandlers = new ArrayList<>();
    private final List<BotDeathHandler> deathHandlers = new ArrayList<>();
    private final List<BotAttackHandler> attackHandlers = new ArrayList<>();
    private final List<BotDamageHandler> damageHandlers = new ArrayList<>();
    private final List<BotTickHandler> tickHandlers = new ArrayList<>();
    
    private BotEventManager() {}
    
    public static BotEventManager getInstance() {
        return INSTANCE;
    }
    
    
    public void registerSpawnHandler(BotSpawnHandler handler) {
        spawnHandlers.add(handler);
    }
    
    
    public void registerDeathHandler(BotDeathHandler handler) {
        deathHandlers.add(handler);
    }
    
    
    public void registerAttackHandler(BotAttackHandler handler) {
        attackHandlers.add(handler);
    }
    
    
    public void registerDamageHandler(BotDamageHandler handler) {
        damageHandlers.add(handler);
    }
    
    
    public void registerTickHandler(BotTickHandler handler) {
        tickHandlers.add(handler);
    }
    
    
    public void fireSpawnEvent(class_3222 bot) {
        for (BotSpawnHandler handler : spawnHandlers) {
            try {
                handler.onBotSpawn(bot);
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in spawn handler: " + e.getMessage());
            }
        }
    }
    
    
    public void fireDeathEvent(class_3222 bot) {
        for (BotDeathHandler handler : deathHandlers) {
            try {
                handler.onBotDeath(bot);
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in death handler: " + e.getMessage());
            }
        }
    }
    
    
    public boolean fireAttackEvent(class_3222 bot, class_1297 target) {
        for (BotAttackHandler handler : attackHandlers) {
            try {
                if (handler.onBotAttack(bot, target)) {
                    return true;
                }
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in attack handler: " + e.getMessage());
            }
        }
        return false;
    }
    
    
    public boolean fireDamageEvent(class_3222 bot, class_1297 attacker, float damage) {
        for (BotDamageHandler handler : damageHandlers) {
            try {
                if (handler.onBotDamage(bot, attacker, damage)) {
                    return true;
                }
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in damage handler: " + e.getMessage());
            }
        }
        return false;
    }
    
    
    public void fireTickEvent(class_3222 bot) {
        for (BotTickHandler handler : tickHandlers) {
            try {
                handler.onBotTick(bot);
            } catch (Exception e) {
                System.err.println("[PVP_BOT_API] Error in tick handler: " + e.getMessage());
            }
        }
    }
}
