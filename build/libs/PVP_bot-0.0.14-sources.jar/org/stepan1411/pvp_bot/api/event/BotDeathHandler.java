package org.stepan1411.pvp_bot.api.event;

import net.minecraft.class_3222;


@FunctionalInterface
public interface BotDeathHandler {
    
    void onBotDeath(class_3222 bot);
}
