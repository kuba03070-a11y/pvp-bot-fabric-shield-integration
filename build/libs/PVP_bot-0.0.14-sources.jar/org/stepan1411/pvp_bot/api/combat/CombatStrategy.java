package org.stepan1411.pvp_bot.api.combat;

import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.stepan1411.pvp_bot.bot.BotSettings;


public interface CombatStrategy {
    
    
    String getName();
    
    
    int getPriority();
    
    
    boolean canUse(class_3222 bot, class_1297 target, BotSettings settings);
    
    
    boolean execute(class_3222 bot, class_1297 target, BotSettings settings, MinecraftServer server);
    
    
    default int getCooldown() {
        return 20;
    }
    
    
    default String getDescription() {
        return getName();
    }
    
    
    default boolean isEnabledByDefault() {
        return true;
    }
}
