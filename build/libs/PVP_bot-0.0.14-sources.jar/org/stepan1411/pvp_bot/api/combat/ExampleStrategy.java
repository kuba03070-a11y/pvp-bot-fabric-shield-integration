package org.stepan1411.pvp_bot.api.combat;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.stepan1411.pvp_bot.bot.BotSettings;


public class ExampleStrategy implements CombatStrategy {
    
    @Override
    public String getName() {
        return "ExampleLowHealthBoost";
    }
    
    @Override
    public int getPriority() {
        return 150;
    }
    
    @Override
    public String getDescription() {
        return "Applies strength boost when bot health is low";
    }
    
    @Override
    public boolean canUse(class_3222 bot, class_1297 target, BotSettings settings) {

        float healthPercent = bot.method_6032() / bot.method_6063();
        

        if (bot.method_6059(class_1294.field_5910)) {
            return false;
        }
        

        return healthPercent < 0.5f && bot.method_5739(target) < 8.0;
    }
    
    @Override
    public boolean execute(class_3222 bot, class_1297 target, BotSettings settings, MinecraftServer server) {
        try {

            bot.method_6092(new class_1293(
                class_1294.field_5910, 
                200,
                1
            ));
            

            bot.method_64398(class_2561.method_43470("§c[Strategy] Low health boost activated!"));
            

            System.out.println("[PVP_BOT_API] ExampleStrategy executed for " + bot.method_5477().getString());
            
            return true;
        } catch (Exception e) {
            System.err.println("[PVP_BOT_API] Error in ExampleStrategy: " + e.getMessage());
            return false;
        }
    }
    
    @Override
    public int getCooldown() {
        return 300;
    }
}