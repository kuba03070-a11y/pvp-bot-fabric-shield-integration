package org.stepan1411.pvp_bot.api.event;

import net.minecraft.class_3222;

/**
 * Handler for bot tick events
 */
@FunctionalInterface
public interface BotTickHandler {
    /**
     * Called every tick for each bot
     * @param bot The bot being ticked
     */
    void onBotTick(class_3222 bot);
}
