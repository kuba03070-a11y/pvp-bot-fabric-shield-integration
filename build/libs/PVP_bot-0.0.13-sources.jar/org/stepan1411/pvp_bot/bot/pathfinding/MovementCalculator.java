package org.stepan1411.pvp_bot.bot.pathfinding;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

/**
 * Calculates possible movements from a position
 * Inspired by Baritone's Moves system
 */
public class MovementCalculator {
    
    // Movement costs (inspired by Baritone's ActionCosts)
    public static final double WALK_ONE_BLOCK_COST = 20.0 / 4.317; // ticks / blocks per second
    public static final double WALK_ONE_IN_WATER_COST = 20.0 / 2.2;
    public static final double JUMP_ONE_BLOCK_COST = 20.0 / 4.0;
    public static final double FALL_N_BLOCKS_COST = 20.0 / 10.0; // falling is fast
    public static final double DIAGONAL_COST = WALK_ONE_BLOCK_COST * 1.414;
    public static final double CLIMB_COST = 20.0 / 2.35;
    
    private final class_1937 world;
    
    public MovementCalculator(class_1937 world) {
        this.world = world;
    }
    
    /**
     * Get all possible movements from a position
     * Inspired by Baritone's movement calculation
     */
    public List<PossibleMovement> getMovements(class_2338 from) {
        List<PossibleMovement> movements = new ArrayList<>();
        
        // Cardinal directions
        addTraverseMovement(movements, from, 1, 0);   // East
        addTraverseMovement(movements, from, -1, 0);  // West
        addTraverseMovement(movements, from, 0, 1);   // South
        addTraverseMovement(movements, from, 0, -1);  // North
        
        // Diagonal directions
        addDiagonalMovement(movements, from, 1, 1);   // SE
        addDiagonalMovement(movements, from, 1, -1);  // NE
        addDiagonalMovement(movements, from, -1, 1);  // SW
        addDiagonalMovement(movements, from, -1, -1); // NW
        
        // Vertical movements
        addPillarMovement(movements, from);
        addFallMovement(movements, from);
        
        // Climbing
        if (isClimbable(from) || isClimbable(from.method_10084())) {
            addClimbMovement(movements, from);
        }
        
        return movements;
    }
    
    /**
     * Traverse - walk forward on same level or descend one block
     */
    private void addTraverseMovement(List<PossibleMovement> movements, class_2338 from, int dx, int dz) {
        class_2338 to = from.method_10069(dx, 0, dz);
        
        // Check if destination is a stair block (special handling)
        if (isStairs(to)) {
            // Stairs are walkable, treat as ascend
            if (canPassThrough(to.method_10084()) && canPassThrough(to.method_10086(2))) {
                movements.add(new PossibleMovement(to, WALK_ONE_BLOCK_COST * 1.2, MovementType.ASCEND));
            }
            return;
        }
        
        // Check if can walk on same level
        if (canWalkOn(to)) {
            movements.add(new PossibleMovement(to, WALK_ONE_BLOCK_COST, MovementType.TRAVERSE));
            return;
        }
        
        // Check if can ascend (jump up one block)
        class_2338 ascend = to.method_10084();
        if (canWalkOn(ascend) && canPassThrough(from.method_10084()) && canPassThrough(from.method_10086(2))) {
            movements.add(new PossibleMovement(ascend, JUMP_ONE_BLOCK_COST, MovementType.ASCEND));
            return;
        }
        
        // Check if can descend (walk down one block)
        class_2338 descend = to.method_10074();
        if (canWalkOn(descend)) {
            movements.add(new PossibleMovement(descend, WALK_ONE_BLOCK_COST * 1.2, MovementType.DESCEND));
        }
    }
    
    /**
     * Diagonal movement
     */
    private void addDiagonalMovement(List<PossibleMovement> movements, class_2338 from, int dx, int dz) {
        class_2338 to = from.method_10069(dx, 0, dz);
        
        // Check if both adjacent blocks are passable (can't cut corners)
        class_2338 side1 = from.method_10069(dx, 0, 0);
        class_2338 side2 = from.method_10069(0, 0, dz);
        
        if (!canPassThrough(side1) && !canPassThrough(side2)) {
            return; // Both sides blocked, can't move diagonally
        }
        
        if (canWalkOn(to)) {
            movements.add(new PossibleMovement(to, DIAGONAL_COST, MovementType.DIAGONAL));
        }
    }
    
    /**
     * Pillar - jump straight up
     */
    private void addPillarMovement(List<PossibleMovement> movements, class_2338 from) {
        class_2338 up = from.method_10084();
        if (canWalkOn(up) && canPassThrough(from.method_10084()) && canPassThrough(from.method_10086(2))) {
            movements.add(new PossibleMovement(up, JUMP_ONE_BLOCK_COST * 1.5, MovementType.PILLAR));
        }
    }
    
    /**
     * Fall - fall down multiple blocks
     */
    private void addFallMovement(List<PossibleMovement> movements, class_2338 from) {
        // Check falling straight down
        for (int fallDist = 1; fallDist <= 4; fallDist++) {
            class_2338 down = from.method_10087(fallDist);
            
            // Check if path is clear
            boolean pathClear = true;
            for (int i = 1; i < fallDist; i++) {
                if (!canPassThrough(from.method_10087(i))) {
                    pathClear = false;
                    break;
                }
            }
            
            if (pathClear && canWalkOn(down)) {
                double cost = FALL_N_BLOCKS_COST * fallDist;
                movements.add(new PossibleMovement(down, cost, MovementType.FALL));
                break; // Only add first valid fall
            }
        }
    }
    
    /**
     * Climb - climb up ladders/vines
     */
    private void addClimbMovement(List<PossibleMovement> movements, class_2338 from) {
        class_2338 up = from.method_10084();
        if (isClimbable(up) && canPassThrough(up.method_10084())) {
            movements.add(new PossibleMovement(up, CLIMB_COST, MovementType.CLIMB));
        }
    }
    
    /**
     * Check if can walk on this position (has solid ground, clear space above)
     */
    private boolean canWalkOn(class_2338 pos) {
        class_2680 belowState = world.method_8320(pos.method_10074());
        
        // Stairs are special - can walk on them
        if (isStairs(pos.method_10074())) {
            return canPassThrough(pos) && canPassThrough(pos.method_10084());
        }
        
        // Must have solid ground below
        if (!isSolid(pos.method_10074())) {
            return false;
        }
        
        // Must have clear space for feet and head
        if (!canPassThrough(pos) || !canPassThrough(pos.method_10084())) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Check if can pass through this position (air, liquid, or non-solid)
     */
    private boolean canPassThrough(class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return state.method_26215() || state.method_51176() || !state.method_26212(world, pos);
    }
    
    /**
     * Check if block is solid
     */
    private boolean isSolid(class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return !state.method_26215() && state.method_26212(world, pos);
    }
    
    /**
     * Check if position is climbable
     */
    private boolean isClimbable(class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return state.method_26204() instanceof net.minecraft.class_2399 ||
               state.method_26204() instanceof net.minecraft.class_2541 ||
               state.method_27852(net.minecraft.class_2246.field_16492) ||
               state.method_27852(net.minecraft.class_2246.field_23078) ||
               state.method_27852(net.minecraft.class_2246.field_22123);
    }
    
    /**
     * Check if position is a stair block
     */
    private boolean isStairs(class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        return state.method_26204() instanceof net.minecraft.class_2510;
    }
    
    /**
     * Represents a possible movement
     */
    public static class PossibleMovement {
        public final class_2338 destination;
        public final double cost;
        public final MovementType type;
        
        public PossibleMovement(class_2338 destination, double cost, MovementType type) {
            this.destination = destination;
            this.cost = cost;
            this.type = type;
        }
    }
}
