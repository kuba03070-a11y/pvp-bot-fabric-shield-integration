package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Uses Carpet mod commands for bot movement
 * Provides more natural and smooth movement than manual velocity control
 */
public class CarpetMovement {
    
    private static boolean carpetAvailable = false;
    
    static {
        try {
            // Check if Carpet mod is loaded
            Class.forName("carpet.CarpetServer");
            carpetAvailable = true;
        } catch (ClassNotFoundException e) {
            carpetAvailable = false;
        }
    }
    
    /**
     * Check if Carpet mod is available
     */
    public static boolean isCarpetAvailable() {
        return carpetAvailable;
    }
    
    /**
     * Make bot walk towards a position using Carpet commands
     */
    public static boolean walkTowards(class_3222 bot, class_243 targetPos) {
        if (!carpetAvailable) {
            return false;
        }
        
        try {
            MinecraftServer server = bot.method_64396().method_9211();
            if (server == null) {
                return false;
            }
            
            String botName = bot.method_5477().getString();
            class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
            
            // Calculate direction
            double dx = targetPos.field_1352 - botPos.field_1352;
            double dz = targetPos.field_1350 - botPos.field_1350;
            double dist = Math.sqrt(dx * dx + dz * dz);
            
            if (dist < 0.5) {
                // Close enough, stop
                stopMovement(bot);
                return true;
            }
            
            // Calculate yaw angle
            double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
            
            // Execute Carpet command: /player <name> look <yaw> <pitch>
            executeCommand(server, String.format("player %s look %.1f 0", botName, yaw));
            
            // Execute Carpet command: /player <name> move forward
            executeCommand(server, String.format("player %s move forward", botName));
            
            // Sprint if far away
            if (dist > 3.0) {
                executeCommand(server, String.format("player %s sprint", botName));
            }
            
            // Jump if needed
            double dy = targetPos.field_1351 - botPos.field_1351;
            if (dy > 0.5 && bot.method_24828()) {
                executeCommand(server, String.format("player %s jump", botName));
            }
            
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Stop bot movement
     */
    public static void stopMovement(class_3222 bot) {
        if (!carpetAvailable) {
            return;
        }
        
        try {
            MinecraftServer server = bot.method_64396().method_9211();
            if (server == null) {
                return;
            }
            
            String botName = bot.method_5477().getString();
            
            // Stop all movement
            executeCommand(server, String.format("player %s stop", botName));
        } catch (Exception e) {
            // Ignore
        }
    }
    
    /**
     * Make bot jump
     */
    public static void jump(class_3222 bot) {
        if (!carpetAvailable) {
            return;
        }
        
        try {
            MinecraftServer server = bot.method_64396().method_9211();
            if (server == null) {
                return;
            }
            
            String botName = bot.method_5477().getString();
            executeCommand(server, String.format("player %s jump", botName));
        } catch (Exception e) {
            // Ignore
        }
    }
    
    /**
     * Make bot sprint
     */
    public static void sprint(class_3222 bot, boolean enable) {
        if (!carpetAvailable) {
            return;
        }
        
        try {
            MinecraftServer server = bot.method_64396().method_9211();
            if (server == null) {
                return;
            }
            
            String botName = bot.method_5477().getString();
            if (enable) {
                executeCommand(server, String.format("player %s sprint", botName));
            } else {
                executeCommand(server, String.format("player %s unsprint", botName));
            }
        } catch (Exception e) {
            // Ignore
        }
    }
    
    /**
     * Make bot look at position
     */
    public static void lookAt(class_3222 bot, class_243 targetPos) {
        if (!carpetAvailable) {
            return;
        }
        
        try {
            MinecraftServer server = bot.method_64396().method_9211();
            if (server == null) {
                return;
            }
            
            String botName = bot.method_5477().getString();
            class_243 botPos = bot.method_33571();
            
            // Calculate angles
            double dx = targetPos.field_1352 - botPos.field_1352;
            double dy = targetPos.field_1351 - botPos.field_1351;
            double dz = targetPos.field_1350 - botPos.field_1350;
            
            double horizontalDist = Math.sqrt(dx * dx + dz * dz);
            double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
            double pitch = -Math.toDegrees(Math.atan2(dy, horizontalDist));
            
            executeCommand(server, String.format("player %s look %.1f %.1f", botName, yaw, pitch));
        } catch (Exception e) {
            // Ignore
        }
    }
    
    /**
     * Execute Carpet command (public for direct use)
     */
    public static void executeCommand(MinecraftServer server, String command) {
        try {
            server.method_3734().method_9235().execute(command, server.method_3739());
        } catch (Exception e) {
            // Silently fail if command doesn't work
        }
    }
}
