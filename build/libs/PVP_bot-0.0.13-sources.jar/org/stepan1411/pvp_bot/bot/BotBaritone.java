package org.stepan1411.pvp_bot.bot;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.stepan1411.pvp_bot.bot.pathfinding.AStarPathfinder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Server-side pathfinding system for bots
 * 
 * NOTE: Original Baritone is designed for client-side use and requires ClientPlayerEntity.
 * This implementation uses A* pathfinding algorithm adapted for ServerPlayerEntity.
 */
public class BotBaritone {
    
    private static final Map<String, PathState> pathStates = new HashMap<>();
    
    private static class PathState {
        List<class_243> currentPath;
        int currentIndex;
        class_243 targetPos;
        long lastPathTime;
        
        PathState(List<class_243> path, class_243 target) {
            this.currentPath = path;
            this.currentIndex = 0;
            this.targetPos = target;
            this.lastPathTime = System.currentTimeMillis();
        }
    }
    
    /**
     * Check if pathfinding is available
     * Always returns true as we use server-side A* pathfinding
     */
    public static boolean isBaritoneAvailable(class_3222 bot) {
        return true;
    }
    
    /**
     * Move bot to a specific position using A* pathfinding
     */
    public static boolean goToPosition(class_3222 bot, class_243 targetPos) {
        String botName = bot.method_5477().getString();
        PathState state = pathStates.get(botName);
        
        // Check if we need to recalculate path
        boolean needNewPath = state == null || 
                              state.currentPath == null || 
                              state.currentIndex >= state.currentPath.size() ||
                              !state.targetPos.method_24802(targetPos, 2.0) ||
                              System.currentTimeMillis() - state.lastPathTime > 5000; // Recalc every 5 sec
        
        if (needNewPath) {
            List<class_243> path = AStarPathfinder.findPath(bot, targetPos);
            if (path == null || path.isEmpty()) {
                return false; // No path found
            }
            state = new PathState(path, targetPos);
            pathStates.put(botName, state);
        }
        
        // Follow current path
        if (state.currentIndex < state.currentPath.size()) {
            class_243 nextPoint = state.currentPath.get(state.currentIndex);
            class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
            
            // Debug visualization - show full path
            if (BotDebug.isEnabled(botName)) {
                BotDebug.showPath(bot, targetPos, new java.util.LinkedList<>(), state.currentPath);
            }
            
            // Check if reached current waypoint (smaller radius for precision)
            double horizontalDist = Math.sqrt(
                Math.pow(nextPoint.field_1352 - botPos.field_1352, 2) + 
                Math.pow(nextPoint.field_1350 - botPos.field_1350, 2)
            );
            double verticalDist = Math.abs(nextPoint.field_1351 - botPos.field_1351);
            
            // More precise waypoint checking
            if (horizontalDist < 0.5 && verticalDist < 1.0) {
                state.currentIndex++;
                if (state.currentIndex >= state.currentPath.size()) {
                    // Reached end of path
                    return true;
                }
                nextPoint = state.currentPath.get(state.currentIndex);
            }
            
            // Move toward next waypoint using Carpet commands with our pathfinding
            BotNavigation.NavigationState navState = BotNavigation.getState(bot.method_5477().getString());
            if (navState.jumpCooldown > 0) navState.jumpCooldown--;
            if (navState.avoidTicks > 0) navState.avoidTicks--;
            
            // Calculate direction to waypoint
            double dx = nextPoint.field_1352 - botPos.field_1352;
            double dz = nextPoint.field_1350 - botPos.field_1350;
            double dist = Math.sqrt(dx * dx + dz * dz);
            
            if (dist > 0.1) {
                // Calculate yaw to look at waypoint
                double yaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
                double dy = nextPoint.field_1351 - botPos.field_1351;
                
                // Try Carpet commands first
                if (CarpetMovement.isCarpetAvailable()) {
                    MinecraftServer server = bot.method_64396().method_9211();
                    
                    // Look at waypoint
                    CarpetMovement.executeCommand(server, String.format("player %s look %.1f 0", botName, yaw));
                    
                    // Move forward toward waypoint
                    CarpetMovement.executeCommand(server, String.format("player %s move forward", botName));
                    
                    // Sprint if far
                    if (dist > 3.0) {
                        CarpetMovement.executeCommand(server, String.format("player %s sprint", botName));
                    }
                    
                    // Jump if needed
                    if (dy > 0.5 && bot.method_24828() && navState.jumpCooldown <= 0) {
                        CarpetMovement.executeCommand(server, String.format("player %s jump", botName));
                        navState.jumpCooldown = 10;
                    }
                } else {
                    // Fallback to manual movement
                    dx /= dist;
                    dz /= dist;
                    
                    // Look at waypoint
                    float yawF = (float) yaw;
                    bot.method_36456(yawF);
                    bot.method_5847(yawF);
                    
                    // Always sprint for speed
                    bot.method_5728(true);
                    bot.field_6250 = 1.0f;
                    
                    // Apply velocity - stronger for faster movement
                    bot.method_5762(dx * 0.15, 0, dz * 0.15);
                    
                    // Bhop - jump while running for extra speed
                    BotSettings settings = BotSettings.get();
                    if (bot.method_24828() && navState.jumpCooldown <= 0) {
                        // Jump if going up OR bhop if enabled and moving fast
                        if (dy > 0.5) {
                            // Need to jump up
                            bot.method_6043();
                            navState.jumpCooldown = 10;
                        } else if (settings.isBhopEnabled() && dist > 2.0) {
                            // Bhop for speed on flat ground
                            bot.method_6043();
                            navState.jumpCooldown = settings.getBhopCooldown();
                        }
                    }
                }
            }
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Move bot near an entity using A* pathfinding
     */
    public static boolean goToEntity(class_3222 bot, class_1297 target, double distance) {
        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        return goToPosition(bot, targetPos);
    }
    
    /**
     * Move bot away from an entity
     * Uses direct navigation instead of pathfinding for retreat
     */
    public static boolean moveAwayFrom(class_3222 bot, class_1297 target, double minDistance) {
        // For retreat, direct navigation is faster than pathfinding
        return false; // Let BotNavigation handle it
    }
    
    /**
     * Stop current pathfinding
     */
    public static void stop(class_3222 bot) {
        String botName = bot.method_5477().getString();
        pathStates.remove(botName);
    }
    
    /**
     * Check if bot is currently pathfinding
     */
    public static boolean isPathing(class_3222 bot) {
        String botName = bot.method_5477().getString();
        PathState state = pathStates.get(botName);
        return state != null && state.currentPath != null && state.currentIndex < state.currentPath.size();
    }
    
    /**
     * Get distance to current goal
     */
    public static double getDistanceToGoal(class_3222 bot) {
        String botName = bot.method_5477().getString();
        PathState state = pathStates.get(botName);
        if (state == null || state.targetPos == null) {
            return -1;
        }
        class_243 botPos = new class_243(bot.method_23317(), bot.method_23318(), bot.method_23321());
        return botPos.method_1022(state.targetPos);
    }
    
    /**
     * Remove pathfinding state when bot is removed
     */
    public static void removeBaritone(String botName) {
        pathStates.remove(botName);
    }
}
